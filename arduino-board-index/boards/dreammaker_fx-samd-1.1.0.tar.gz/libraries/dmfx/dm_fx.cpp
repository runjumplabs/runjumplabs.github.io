/**
 * Copyright (c) 2019 Run Jump Labs LLC.  All right reserved. 
 * 
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either  
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details. 
 * 
 * The GNU Lesser General Public License can be found here:
 * https://www.gnu.org/licenses/lgpl-3.0.en.html
 * 
 * Or write to the Free Software Foundation, Inc., 
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <stdlib.h>

#include "Arduino.h"
#include "dm_fx.h"

fx_canvas pedal;


/************************************************************************
 *
 *                        HELPER FUNCTIONS
 *
 ***********************************************************************/
char * get_effect_type(EFFECT_TYPE t) {
  if (t == FX_NONE) return "none";
  else if (t == FX_AMPLITUDE_MODULATOR) return "amplitude modulator";
  else if (t == FX_BIQUAD_FILTER) return "biquad filter";
  else if (t == FX_CLIPPER) return "clipper";
  else if (t == FX_COMPRESSOR) return "compressor";
  else if (t == FX_DELAY) return "delay";
  else if (t == FX_GAIN) return "gain";  
  else if (t == FX_MIXER_2) return "mixer x 2";  
  else if (t == FX_MIXER_3) return "mixer x 3";  
  else if (t == FX_MIXER_4) return "mixer x 4";  
  else if (t == FX_RING_MOD) return "ring modulator";
  else if (t == FX_SHAPER) return "shaper";
  else if (t == FX_LOOPER) return "looper";
  else if (t == FX_OSCILLATOR) return "oscillator";
  else if (t == FX_PHASE_SHIFTER) return "phase shifter";
  else if (t == FX_PITCH_SHIFT) return "pitch shift";
  else if (t == FX_SLICER) return "slicer";
  else if (t == FX_VARIABLE_DELAY) return "variable delay";
  else if (t == FX_UNDEFINED) return "undefined";
  else if (t == CANVAS) return "canvas";
}

/************************************************************************
 *
 *                        WM8731 support
 *
 ***********************************************************************/

#define WM8731_R0_LEFT_LINE_CTRL     (0x00)
#define WM8731_R1_RIGHT_LINE_CTRL    (0x02)
#define WM8731_R2_LEFT_HP_CTRL       (0x04)
#define WM8731_R3_RIGHT_HP_CTRL      (0x06)
#define WM8731_R4_ANALOG_PATH_CTRL   (0x08)
#define WM8731_R5_DIGITAL_PATH_CTRL  (0x0A)
#define WM8731_R6_PWR_DOWN_CTRL      (0x0C)
#define WM8731_R7_DIGITAL_IFACE_CTRL (0x0E)
#define WM8731_R8_SAMPLING_CTRL      (0x10)
#define WM8731_R9_ACTIVE_CTRL        (0x12)
#define WM8731_RF_RESET_CTRL         (0x1E)

static void  wm8731_write_register(uint8_t addr, uint8_t val) {
  Wire2.beginTransmission(0x1a);
  Wire2.write(addr);  
  Wire2.write(val); 
  Wire2.endTransmission();
}

/**
 * @brief      Initializes the WM8731 codec 
 */
static void wm8731_initialize(void) {
  Wire2.begin();
  wm8731_write_register(WM8731_RF_RESET_CTRL, 0x0);
  wm8731_write_register(WM8731_R6_PWR_DOWN_CTRL, 0x0);             // turn everything on
  wm8731_write_register(WM8731_R0_LEFT_LINE_CTRL,     B00010111);  // configure L ADC gain
  wm8731_write_register(WM8731_R1_RIGHT_LINE_CTRL,    B00010111);  // configure R ADC input gain
  wm8731_write_register(WM8731_R2_LEFT_HP_CTRL, 0);                // disable headphones
  wm8731_write_register(WM8731_R3_RIGHT_HP_CTRL, 0);               // disable headphones
  wm8731_write_register(WM8731_R4_ANALOG_PATH_CTRL,   B00010010);  // send DAC outputs to lineout
  wm8731_write_register(WM8731_R5_DIGITAL_PATH_CTRL,  B00000110);  // 48kHz deemphasis, disable soft mute on dac
  wm8731_write_register(WM8731_R7_DIGITAL_IFACE_CTRL, B01001110);  // 32-bit I2S data / I2S master
  wm8731_write_register(WM8731_R8_SAMPLING_CTRL, 0);               // 48kHz / 256FS
  wm8731_write_register(WM8731_R9_ACTIVE_CTRL, 1);                 // Start codec
}


/************************************************************************
 *
 *                        SPI Protocol
 *
 ***********************************************************************/

#define MAX_SPI_BLOCK_SIZE      (64)
#define SPI_FIFO_SIZE           (2048)
#define SPI_FIFO_MASK           (SPI_FIFO_SIZE-1)

#define SPI_RX_FRAME_SIZE       (16)
#define SPI_RX_PAYLOAD_SIZE     (13)

// SPI Interface
uint16_t    spi_tx_fifo[SPI_FIFO_SIZE];
uint16_t    spi_rx_frame[SPI_RX_FRAME_SIZE];


// DSP status structure
DSP_STATUS   dsp_status;

// Initialize SPI communications
uint16_t  spi_tx_wr_ptr = 0;
uint16_t  spi_tx_rd_ptr = 0;
int16_t   spi_rx_wr_ptr = 0;
SPI_RX_STATE  spi_rx_state = SPI_RX_WAITING;
uint16_t  spi_service_last_millis = 0;

/**
  * @brief Push a 16-bit word into the FIFO
  */ 
bool spi_fifo_push(uint16_t val) {

  if (SPI_FIFO_MASK & (spi_tx_wr_ptr+1) == spi_tx_rd_ptr) {
    Serial.println("spi_fifo_push() failed");
    return false;
  }
  spi_tx_fifo[spi_tx_wr_ptr++] = val;
    
  spi_tx_wr_ptr &= SPI_FIFO_MASK;

  return true;

}

/**
 * @brief Returns the number of free words in the FIFO
 */
uint16_t spi_fifo_available_space(void) {
  if (spi_tx_wr_ptr > spi_tx_rd_ptr) {
    return SPI_FIFO_SIZE - (spi_tx_wr_ptr - spi_tx_rd_ptr);
  } 

  else if (spi_tx_rd_ptr > spi_tx_wr_ptr) {
    return (spi_tx_rd_ptr - spi_tx_wr_ptr) - 1;
  } 

  else {
    return SPI_FIFO_SIZE;
  }
}

/**
 * @brief  Adds a SPI transmission frame to the SPI FIFO
 * 
 * A SPI transmission block basically has the lenght of the block in the first location
 * and is followed by the block of data
 *
 * @param      data  The data
 * @param[in]  size  The size
 * 
 * return   False if size is greater than max SPI block size
 */
bool  spi_fifo_insert_block(uint16_t * data, uint16_t size) {

  uint16_t spi_block[MAX_SPI_BLOCK_SIZE];

  // Check if block exceeds size
  if (size > MAX_SPI_BLOCK_SIZE) {
    Serial.println("Error: SPI block size too big");
    return false;
  }

  // Check if block will fit in the fifo
  if (size > spi_fifo_available_space()) {
    Serial.println("Error: SPI FIFO full");
    return false;
  }

  // Add frame to FIFO

  // 1. Add frame headers
  spi_fifo_push(FRAME_HEADER_1);
  spi_fifo_push(FRAME_HEADER_2);
  
  // 2. Add frame size
  spi_fifo_push(size);

  // 3. Add frame payload
  for (int i=0;i<size;i++) {
    spi_fifo_push(data[i]);
  }

  // 4. Add frame terminator
  spi_fifo_push(FRAME_TERMINATOR);

}



/**
 * @brief      Process a frame we just got from the DSP
 *
 */
void spi_process_received_frame(uint16_t * rx_frame) {
  
  dsp_status.valid = true;
  dsp_status.firmware_maj = rx_frame[0];
  dsp_status.firmware_min = rx_frame[1];
  dsp_status.canvas_running = rx_frame[2];
  dsp_status.loading_percentage = rx_frame[3] * (1.0/65536.0); 

  static bool first_time = true;

}


/**
 * @brief      Transmits any frames to the DSP
 */
void spi_transmit_buffered_frames(void) {

  static uint8_t  rx_frame_state = 0;
  static uint16_t rx_frame_ptr = 0;
  static uint16_t rx_frame_buf[16];

  // If there are no words in the fifo, return
  if (spi_tx_wr_ptr == spi_tx_rd_ptr) {
    return;
  }  


  // If we last serviced the spi port less than 10 milliseconds ago, hold off
  uint32_t now = millis();
  if (spi_service_last_millis + 10 > now) {
    return;
  }
  spi_service_last_millis = now;

  // Begin SPI transaction
  SPI.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
  digitalWrite(SPI_SS_PIN, LOW);

  uint16_t rx_word;
  while (spi_tx_wr_ptr != spi_tx_rd_ptr) {

    // SPI TX/RX operation
    rx_word = SPI.transfer16(spi_tx_fifo[spi_tx_rd_ptr++]);
    if (spi_tx_rd_ptr >= SPI_FIFO_SIZE) {
      spi_tx_rd_ptr = 0;
    }

    // SPI process received frame
    if (spi_rx_state == SPI_RX_RECEIVING && rx_word == FRAME_TERMINATOR) {
      spi_rx_state = SPI_RX_WAITING;
      spi_process_received_frame(spi_rx_frame);
    } else if (spi_rx_state == SPI_RX_RECEIVING) {
      spi_rx_frame[spi_rx_wr_ptr++] = rx_word;

      // if we've received a complete frame, set state to ready
      if (spi_rx_wr_ptr >= SPI_RX_PAYLOAD_SIZE) {
        spi_rx_wr_ptr = SPI_RX_PAYLOAD_SIZE - 1;
      }
    }
    else if (spi_rx_state == SPI_RX_WAITING && rx_word == FRAME_HEADER_1) {
      spi_rx_state = SPI_RX_HEADER_1_RX;
    } 
    else if (spi_rx_state == SPI_RX_HEADER_1_RX && rx_word == FRAME_HEADER_2) {
      spi_rx_state = SPI_RX_RECEIVING;
      spi_rx_wr_ptr = 0;

    } 
    
  }

  // End transaction
  digitalWrite(SPI_SS_PIN, HIGH);  
  SPI.endTransaction();

}


/**
 * @brief      Fetches DSP status over the SPI port
 */
bool wait_for_dsp_to_boot(void) {

  // Invalidate info in dsp_status struct
  dsp_status.valid = false;

  int timeout_cntr = 100;
  while (!dsp_status.valid && timeout_cntr--) {
    for (int i=0;i<20;i++) {
      spi_fifo_push(0);
    }
    spi_transmit_buffered_frames();
    delay(100);
  }

  if (dsp_status.valid) {
    Serial.print(" DSP firmware version: ");
    Serial.print(dsp_status.firmware_maj);
    Serial.print(".");
    Serial.println(dsp_status.firmware_min);
  } else {
    Serial.println("Error: timeout waiting for DSP to come to life");
    while(1);
  }

  return dsp_status.valid;

}


bool wait_for_canvas_to_start(void) {

  dsp_status.canvas_running = false;
  int timeout_cntr = 100;

  while (!dsp_status.canvas_running && timeout_cntr--) {
    for (int i=0;i<20;i++) {
      spi_fifo_push(0);
    }
    spi_transmit_buffered_frames();
    delay(100);
  }

  return dsp_status.canvas_running;
} 




/************************************************************************
 *
 *                        UI Controls
 *
 ***********************************************************************/

void footswitch_1_pressed(void) __attribute__((weak));
void footswitch_1_pressed(void){
  if (Serial) {
    Serial.println("SW1 pressed but no callback defined");
  }
}

void footswitch_2_pressed(void) __attribute__((weak));
void footswitch_2_pressed(void){
  if (Serial) {
    Serial.println("SW2 pressed but no callback defined");
  }
}

void user_pb_pressed(void) __attribute__((weak));
void user_pb_pressed(void){
  if (Serial) {
    Serial.println("User PB pressed but no callback defined");
  }
}



/************************************************************************
 *
 *                        DSP Controls
 *
 ***********************************************************************/


/**
 * @brief      Resets the DSP
 */
void  dsp_reset(void) {
  digitalWrite(PIN_DSP_RESET, LOW);
  delay(10);
  digitalWrite(PIN_DSP_RESET, HIGH);
  delay(50);
}


/************************************************************************
 *
 *                        CANVAS FUNCTIONS
 *
 ***********************************************************************/

void fx_canvas::init(void) {
  init(false);
}

void  fx_canvas::init(bool debug) {

  debug_mode = debug;

#if 0
  const int button_sw1 = 9;
  const int button_sw2 = 10;
  const int button_sw3 = 11;
  const int button_sw4 = 12;

   // Set up push buttons
  pinMode(button_sw1, INPUT);
  pinMode(button_sw2, INPUT);
  pinMode(button_sw3, INPUT);
  pinMode(button_sw4, INPUT);

  // Attach interrupts
  attachInterrupt(digitalPinToInterrupt(button_sw1), sw1_pressed, FALLING);
  attachInterrupt(digitalPinToInterrupt(button_sw2), sw2_pressed, FALLING);
  attachInterrupt(digitalPinToInterrupt(button_sw3), sw3_pressed, FALLING);
  attachInterrupt(digitalPinToInterrupt(button_sw4), sw4_pressed, FALLING);
#endif 



  // Set up telemetry link to SHARC
  Serial1.begin(115200);
 

  // Initialize the WM8731
  wm8731_initialize();

  // Initialize hardware pins
  pinMode(PIN_FOOTSW_1, INPUT);
  pinMode(PIN_FOOTSW_2, INPUT);
  pinMode(PIN_USR_PB, INPUT);

  attachInterrupt(digitalPinToInterrupt(PIN_FOOTSW_1), footswitch_1_pressed, FALLING);
  attachInterrupt(digitalPinToInterrupt(PIN_FOOTSW_2), footswitch_2_pressed, FALLING);
  attachInterrupt(digitalPinToInterrupt(PIN_USR_PB), user_pb_pressed, FALLING);

  // Setup LEDs
  pinMode(PIN_FOOTSW_LED_1, OUTPUT);
  pinMode(PIN_FOOTSW_LED_2, OUTPUT);
  pinMode(PIN_ARD_LED, OUTPUT);

  // Setup reset line to DSP and reset DSP
  pinMode(PIN_DSP_RESET, OUTPUT);
  digitalWrite(PIN_DSP_RESET, HIGH);

  // Reset the DSP
  dsp_reset();

  // Display a quick alive sequence
  digitalWrite(PIN_ARD_LED, HIGH);
  delay(100);  
  digitalWrite(PIN_ARD_LED, LOW); 
  delay(100);  
  digitalWrite(PIN_ARD_LED, HIGH);
  delay(100);  
  digitalWrite(PIN_ARD_LED, LOW); 
  delay(100);  
  digitalWrite(PIN_ARD_LED, HIGH);
  delay(100);  
  digitalWrite(PIN_ARD_LED, LOW); 
  delay(100);  
  digitalWrite(PIN_ARD_LED, HIGH);


  int now = millis();
  bool timeout = false;
  while ( !Serial && !timeout) {
    if (millis() > now + 3000) {
      timeout = true;
    }
  }
  
  if (!timeout) {
    Serial.begin( 115200 );
    Serial.println("Run Jump Labs - The Dream Leamur");
  }  

  // Set up SPI select line GPIO and set high
  pinMode(SPI_SS_PIN, OUTPUT);
  digitalWrite(SPI_SS_PIN, HIGH);  
  SPI.begin();  

  // Wait for the DSP to boot and report error if it doesn't boot
  wait_for_dsp_to_boot();

  Serial.print(" API version: ");
  Serial.print(API_VERSION_MAJ);
  Serial.print(".");
  Serial.println(API_VERSION_MIN);

  bool firmware_match = true;
  if (dsp_status.firmware_maj != API_VERSION_MAJ) {
    firmware_match = false;
  }
  if (dsp_status.firmware_min != API_VERSION_MIN) {
    firmware_match = false;
  }
  if (!firmware_match) {
    Serial.println("Error: The API version does not match the DSP firmware version");
    while(1);
    
  }

  initialized = true;

}


/**
 * @brief      Adds a new audio route
 *
 * @param[in]  src_id          The source identifier
 * @param[in]  src_node_indx   The source node indx
 * @param[in]  dest_id         The destination identifier
 * @param[in]  dest_node_indx  The destination node indx
 *
 * @return     true if successful, false if not
 */
bool  fx_canvas::add_audio_route_to_stack(uint8_t src_id, 
                                          uint8_t src_node_indx, 
                                          uint8_t dest_id, 
                                          uint8_t dest_node_indx) {
  audio_routing_stack[total_audio_routes].src_id = src_id;
  audio_routing_stack[total_audio_routes].src_node_indx = src_node_indx;
  audio_routing_stack[total_audio_routes].dest_id = dest_id;
  audio_routing_stack[total_audio_routes].dest_node_indx = dest_node_indx;
  total_audio_routes++;

  return true;
}

/**
 * @brief      Adds a control route 
 *
 * @param[in]  src_id          The source identifier
 * @param[in]  src_node_indx   The source node indx
 * @param[in]  dest_id         The destination identifier
 * @param[in]  dest_node_indx  The destination node indx
 *
 * @return     true if successful, false if not
 */
bool  fx_canvas::add_control_route_to_stack(uint8_t src_id, 
                                            uint8_t src_node_indx, 
                                            uint8_t src_param_id, 
                                            uint8_t dest_id,                                             
                                            uint8_t dest_node_indx,
                                            uint8_t dest_param_id, 
                                            float scale,
                                            float offset,
                                            CTRL_NODE_TYPE type) {

  control_routing_stack[total_control_routes].src_id = src_id;
  control_routing_stack[total_control_routes].src_node_indx = src_node_indx;
  control_routing_stack[total_control_routes].src_param_id = src_param_id;
  control_routing_stack[total_control_routes].dest_id = dest_id;
  control_routing_stack[total_control_routes].dest_node_indx = dest_node_indx;
  control_routing_stack[total_control_routes].dest_param_id = dest_param_id;
  control_routing_stack[total_control_routes].scale = scale;
  control_routing_stack[total_control_routes].offset = offset;
  control_routing_stack[total_control_routes].type = type;
  
  total_control_routes++;
  Serial.println("Added control route!!");

  return true;  
}



void  fx_canvas::spi_transmit_control_routing_stack(void) {

  uint16_t routing_block[MAX_SPI_BLOCK_SIZE];

  // serialize routing data
  int indx = 0;
  routing_block[indx++] = HEADER_CONTROL_ROUTING_BLOCK;
  for (int i=0;i<total_control_routes;i++) {
    routing_block[indx++] = (control_routing_stack[i].src_id << 8) | control_routing_stack[i].src_node_indx;
    routing_block[indx++] = (control_routing_stack[i].dest_id << 8) | control_routing_stack[i].dest_node_indx;
    routing_block[indx++] = control_routing_stack[i].src_param_id; 
    routing_block[indx++] = control_routing_stack[i].dest_param_id; 
    float scale = control_routing_stack[i].scale;
    float offset = control_routing_stack[i].offset;
    uint32_t part_32 = * (uint32_t *) &scale;
    routing_block[indx++] = (uint16_t) (part_32 >> 16);
    routing_block[indx++] = (uint16_t) (part_32 & 0xFFFF);
    part_32 = * (uint32_t *) &offset;
    routing_block[indx++] = (uint16_t) (part_32 >> 16);
    routing_block[indx++] = (uint16_t) (part_32 & 0xFFFF);
    routing_block[indx++] = (uint16_t) control_routing_stack[i].type;

  }

  // Copy to SPI transmit fifo
  spi_fifo_insert_block(routing_block, indx);

}

/**
 * @brief  Transmits the routing stack to the DSP
 */
void  fx_canvas::spi_transmit_audio_routing_stack(void) {

  uint16_t routing_block[MAX_SPI_BLOCK_SIZE];

  // serialize routing data
  int indx = 0;
  routing_block[indx++] = HEADER_AUDIO_ROUTING_BLOCK;
  for (int i=0;i<total_audio_routes;i++) {
    routing_block[indx++] = (audio_routing_stack[i].src_id << 8) | audio_routing_stack[i].src_node_indx;
    routing_block[indx++] = (audio_routing_stack[i].dest_id << 8) | audio_routing_stack[i].dest_node_indx;
  }

  // Copy to SPI transmit fifo
  spi_fifo_insert_block(routing_block, indx);

}


/**
 * @brief  Transmits the instance stack to the DSP
 */
void fx_canvas::spi_transmit_instance_stack(void) {
  uint16_t instance_block[MAX_SPI_BLOCK_SIZE];

  // serialize instance data
  int indx = 0;
  instance_block[indx++] = HEADER_INSTANCE_BLOCK;
  for (int i=0;i<total_instances;i++) {
    instance_block[indx++] = (instance_stack[i].type << 8) | instance_stack[i].id; 
  }

  // Copy to SPI transmit fifo
  spi_fifo_insert_block(instance_block, indx);

}

void fx_canvas::spi_transmit_param(EFFECT_TYPE instance_type, uint32_t instance_id, PARAM_TYPES param_type, uint8_t param_id, void * value) {
  
  static uint16_t param_block[7] = {HEADER_SINGLE_PARAMETER};

  uint16_t part_16;
  uint32_t part_32;

  param_block[1] = (uint16_t) instance_type;
  param_block[2] = (uint16_t) instance_id;
  param_block[3] = (uint16_t) param_type;
  param_block[4] = param_id;

  if (param_type == T_BOOL) {
    part_16 = * (uint8_t *) value;
    param_block[5] = part_16;
  }
  else if (param_type == T_INT16) {
    param_block[5] = (uint16_t) (* (uint16_t *) value);
  }
  else if (param_type == T_INT32) {
    param_block[5] = (uint16_t)((* (uint32_t *) value) >> 16);
    param_block[6] = (uint16_t)((* (uint32_t *) value) & 0xFFFF);
  }
  else if (param_type == T_FLOAT) {
    part_32 = * (uint32_t *) value;
    param_block[5] = (uint16_t) (part_32 >> 16);
    param_block[6] = (uint16_t) (part_32 & 0xFFFF);
  }     

  // Add to transmit FIFO
  spi_fifo_insert_block(param_block, sizeof(param_block)/sizeof(uint16_t));

}

/**
 * @brief   Set pedal bypass state
 */
void fx_canvas::spi_transmit_bypass(uint16_t bypass_state) {

  uint16_t param_block[MAX_SPI_BLOCK_SIZE];

  param_block[0] = HEADER_SET_BYPASS;
  param_block[1] = bypass_state; 
 
  // Copy to SPI transmit fifo
  spi_fifo_insert_block(param_block, 2);

}

void fx_canvas::spi_get_status(void) {

  uint16_t param_block[MAX_SPI_BLOCK_SIZE];
  param_block[0] = HEADER_GET_STATUS;

  spi_fifo_insert_block(param_block, SPI_RX_PAYLOAD_SIZE);
  
}

/**
 * @brief   Transmits one set of parameters to the DSP
 */
void fx_canvas::spi_transmit_params(uint16_t node_index) {

  uint16_t param_block[MAX_SPI_BLOCK_SIZE];
  uint16_t size;

  if (!node_index) {
    Serial.println(" spi_transmit_params(): This instance is not part of a canvas");    
    return;
  }

  fx_effect * effect = (fx_effect *) instance_stack[node_index].address;
  
  if (effect == NULL) {
    Serial.println(" spi_transmit_params(): NULL pointer encountered");
    return;
  }

  #if 0
    Serial.println("Generating parameter transmit block");
  #endif 

  size = 0;
  param_block[0] = HEADER_PARAMETER_BLOCK;
  param_block[1] = (uint16_t) instance_stack[node_index].type;  // instance type
  param_block[2] = (uint16_t) instance_stack[node_index].id;    // instance id
  effect->serialize_params(&param_block[3], &size);
  size += 3;

  // Copy to SPI transmit fifo
  spi_fifo_insert_block(param_block, size);

}

/**
 * @brief   Transmits all initial parameters to the DSP
 */
void fx_canvas::spi_transmit_all_params(void) {
  uint16_t param_block[MAX_SPI_BLOCK_SIZE];
  uint16_t size;

  #if 0
    Serial.println("Generating parameter transmit block");
  #endif

  param_block[0] = HEADER_PARAMETER_BLOCK;

  for (int i=1;i<total_instances;i++) {
    size = 0;

    fx_effect * effect = (fx_effect *) instance_stack[i].address;
    
    if (effect == NULL) {
      Serial.println(" spi_transmit_all_params(): NULL pointer encountered");
    } else {
      param_block[1] = (uint16_t) instance_stack[i].type;  // instance type
      param_block[2] = (uint16_t) instance_stack[i].id;    // instance id
      effect->serialize_params(&param_block[3], &size);
      size += 3;

      // Copy to SPI transmit block
      spi_fifo_insert_block(param_block, size);

    }
  }
}




/**
 * @brief Check if any SPI transactions need to happen
 */

void  fx_canvas::spi_service(void) {
  spi_transmit_buffered_frames();
}

/**
 * @brief      Looks up a node in the current node stack
 *
 * @param      node        Pointer to node to look up
 * @param      node_index  Pointer to location node index (output)
 *
 * @return     True if found, false if not
 */
bool  fx_canvas::get_audio_node_index(fx_audio_node * node, uint8_t * node_index) {

  for (int i=0;i<MAX_NODES_PER_FX;i++) {

    if (node == audio_node_stack[i]) {
      *node_index = i;
      return true;
    }
  }
  return false;
}


bool  fx_canvas::get_control_node_index(fx_control_node * node, uint8_t * node_index) {

  for (int i=0;i<MAX_NODES_PER_FX;i++) {

    if (node == control_node_stack[i]) {
      *node_index = i;
      return true;
    }
  }
  return false;
}


/**
 * @brief      Routes a source node (output) to a destination mode (input)
 *
 * @param      src   The source / output
 * @param      dest  The destination / input
 *
 * @return     True is successful, false if not
 */
bool fx_canvas::route_audio(fx_audio_node * src, fx_audio_node * dest) {

  // Ensure inputs and outputs are valid
  if (src->node_direction != NODE_OUT || dest->node_direction != NODE_IN) {
    return false;
  }

  uint8_t src_id, dest_id;

  // Set to false in case we bail mid-way through due to error
  valid_audio_routes = false;

  // Check to see if inputs and outputs are in our stack, and add if not
  if (src->parent_effect != NULL) {
    bool found = false;
    for (int i=0;i<total_instances;i++) {
      if ((void *) src->parent_effect == instance_stack[i].address) {
        found = true;
        src_id = i;
      }
    }
    if (!found) {
      instance_stack[total_instances].address = src->parent_effect; 
      instance_stack[total_instances].type = src->parent_effect->get_type(); 
      instance_stack[total_instances].id = total_instances; 
      src_id = total_instances;      

      // Set instance ID in this effect instance too
      src->parent_effect->instance_id = total_instances;

      total_instances++;


      Serial.println(src->parent_effect->get_name());
    }
  } else if (src->parent_canvas != NULL) {
    src_id = 0;
  }

  if (dest->parent_effect != NULL) {
    bool found = false;
    for (int i=0;i<total_instances;i++) {
      if ((void *) dest->parent_effect == instance_stack[i].address) {
        found = true;
        dest_id = i;
      }
    }
    if (!found) {
      instance_stack[total_instances].address = dest->parent_effect; 
      instance_stack[total_instances].type = dest->parent_effect->get_type(); 
      instance_stack[total_instances].id = total_instances; 
      dest_id = total_instances;

      // Set instance ID in this effect instance too
      dest->parent_effect->instance_id = total_instances;

      total_instances++;
    }
  } else if (src->parent_canvas != NULL) {
    dest_id = 0;
  }

  // Add routes to our routing table
  uint8_t src_node_indx, dest_node_indx;
  bool res;

  // Look up source node
  if (src->parent_effect != NULL) {
    res = src->parent_effect->get_audio_node_index(src, &src_node_indx);
    if (!res) {
      Serial.println("ERROR | route_audio(): Couldn't find this source node in the effect!");
      return false;
    }
  }
  else if (src->parent_canvas != NULL) {
    res = src->parent_canvas->get_audio_node_index(src, &src_node_indx);
    if (!res) {
      Serial.println("ERROR | route_audio(): Couldn't find this source node in the canvas!");
      return false;
    }
  }

  // Look up destination node
  if (dest->parent_effect != NULL) {
    res = dest->parent_effect->get_audio_node_index(dest, &dest_node_indx);
    if (!res) {
      Serial.println("ERROR | route_audio(): Couldn't find this destination node in the effect!");
      return false;
    }
  }
  else if (dest->parent_canvas != NULL) {
    res = dest->parent_canvas->get_audio_node_index(dest, &dest_node_indx);
    if (!res) {
      Serial.println("ERROR | route_audio(): Couldn't find this destination node in the canvas!");
      return false;
    }
  }

  // Set both nodes to connected
  src->connected = true;
  dest->connected = true;

  // Add route to routing table
  add_audio_route_to_stack(src_id, src_node_indx, dest_id, dest_node_indx);

  // Check routing table for any outputs that are being written to twice
  for (int i=0;i<total_audio_routes;i++) {
    for (int j=0;j<total_audio_routes;j++) {
      if (i != j) {
        if ((audio_routing_stack[i].dest_id == audio_routing_stack[j].dest_id) && 
            (audio_routing_stack[i].dest_node_indx == audio_routing_stack[j].dest_node_indx)) {
          Serial.println("Routing error: two different effects writing to same audio node");
          return false;
        }
      }
    }
  }

  // Happy days, we made it
  valid_audio_routes = true;
  return true;
}

bool fx_canvas::route_control(fx_control_node * src, fx_control_node * dest, float scale, float offset) {

  // Set to false in case we bail mid-way through due to error
  valid_control_routes = false;

// Ensure inputs and outputs are valid
  if (src->node_direction != NODE_OUT || dest->node_direction != NODE_IN) {
    Serial.println(" route_control(): src must be output, dest must be input");
    return false;
  }

  uint8_t src_id, dest_id;

  // Check to see if inputs and outputs are in our stack, and add if not
  if (src->parent_effect != NULL) {
    bool found = false;
    for (int i=0;i<total_instances;i++) {
      if ((void *) src->parent_effect == instance_stack[i].address) {
        found = true;
        src_id = i;
      }
    }
    if (!found) {
      instance_stack[total_instances].address = src->parent_effect; 
      instance_stack[total_instances].type = src->parent_effect->get_type(); 
      instance_stack[total_instances].id = total_instances; 
      src_id = total_instances;
      total_instances++;

      Serial.println(src->parent_effect->get_name());
    }
  } else if (src->parent_canvas != NULL) {
    src_id = 0;
  }

  if (dest->parent_effect != NULL) {
    bool found = false;
    for (int i=0;i<total_instances;i++) {
      if ((void *) dest->parent_effect == instance_stack[i].address) {
        found = true;
        dest_id = i;
      }
    }
    if (!found) {
      instance_stack[total_instances].address = dest->parent_effect; 
      instance_stack[total_instances].type = dest->parent_effect->get_type(); 
      instance_stack[total_instances].id = total_instances; 
      dest_id = total_instances;
      total_instances++;
    }
  } else if (src->parent_canvas != NULL) {
    dest_id = 0;
  }

  // Make sure controllers are compatible
  if (dest->node_type != src->node_type) {
    Serial.println("ERROR | route_control(): Trying to connect incompatible controls");
    return false;
  }

  // Add routes to our routing table
  uint8_t src_node_indx, dest_node_indx;
  bool res;

  // Look up source node
  if (src->parent_effect != NULL) {
    res = src->parent_effect->get_control_node_index(src, &src_node_indx);
    if (!res) {
      Serial.println("ERROR | route_control(): Couldn't find the source node in an effect");
      return false;
    }
  }
  else if (src->parent_canvas != NULL) {
    if (src->parent_canvas)
    res = src->parent_canvas->get_control_node_index(src, &src_node_indx);
    if (!res) {
      Serial.println("ERROR | route_control(): Couldn't find the source node in the canvas");
      return false;
    }
  }

  // Look up destination node
  if (dest->parent_effect != NULL) {
    res = dest->parent_effect->get_control_node_index(dest, &dest_node_indx);
    if (!res) {
      Serial.println("ERROR | route_control(): Couldn't find the dest node in an effect");
      return false;
    }
  }
  else if (dest->parent_canvas != NULL) {
    if (dest->parent_canvas)
    res = dest->parent_canvas->get_control_node_index(dest, &dest_node_indx);
    if (!res) {
      Serial.println("ERROR | route_control(): Couldn't find the dest node in the canvas");
      return false;
    }
  }

  // Set both nodes to connected
  src->connected = true;
  dest->connected = true;

  // Add route to routing table
  add_control_route_to_stack(src_id, src_node_indx, src->param_id, dest_id, dest_node_indx, dest->param_id, scale, offset, dest->node_type);

  // Check routing table for any outputs that are being written to twice

  for (int i=0;i<total_control_routes;i++) {
    for (int j=0;j<total_control_routes;j++) {
      if (i != j) {
        if ((control_routing_stack[i].dest_id == control_routing_stack[j].dest_id) && 
            (control_routing_stack[i].dest_node_indx == control_routing_stack[j].dest_node_indx)) {
          Serial.println("Routing error: two different effects writing to same control node");
          return false;
        }
      }
    }
  }

  // Happy days, we made it
  valid_control_routes = true;
  return true;

}

/**
 * @brief      Runs the current canvas (i.e. compiles and downloads to the DSP)
 *
 * @return     True if successful, false if not
 */
bool fx_canvas::run(void) {

  

  // Check to see if our routing is valid
  if (total_audio_routes == 0) {
    Serial.println("ERROR | run(): No routes defined");
    return false;
  }
  if (!valid_audio_routes) {
    Serial.println("ERROR | run(): Errors in the audio routing.  Fix errors in your route_audio() calls.");
    return false;
  }

  if (total_control_routes > 0 && !valid_control_routes) {
    Serial.println("ERROR | run(): Errors in the control routing.  Fix errors in your route_control() calls.");
    return false;
  }  

  // Send routing stack to DSP
  spi_transmit_audio_routing_stack();
  spi_transmit_control_routing_stack();

  // Send instance stack to DSP
  spi_transmit_instance_stack();

  // Send parameters to DSP
  spi_transmit_all_params();

  // Wait for DSP to send message that canvas is running
  wait_for_canvas_to_start();

  if (dsp_status.canvas_running) {
    Serial.println("Effects are running!");
  } else {
    Serial.println("Error: problem encountered while running effects, enable debug mode for more information.");
    while(1);
  }

  return true;

}


/**
 * @brief   Utility function to print the instance stack to the console
 */
void fx_canvas::print_instance_stack() {

  char buf[64];

  Serial.println("Instance stack:");

  sprintf(buf," Total instances: %d", (int) total_instances); Serial.println(buf);
  for (int i=0;i<total_instances;i++) {
    if (instance_stack[i].type != FX_UNDEFINED) {

      sprintf(buf," ID: %#04x", (int) instance_stack[i].id); Serial.println(buf);

      Serial.print("  Type: ");
      Serial.println(get_effect_type(instance_stack[i].type));
      
      sprintf(buf," Address: %#04x", (int) instance_stack[i].address); Serial.println(buf);

    } else {
      Serial.println("Undefined instance found");
    }
  }
  Serial.println();
}

/**
 * @brief   Utility function to print the routing table to the console
 */
void fx_canvas::print_routing_table() {
  
  char buf[64];

  Serial.println("Audio routing table:");

  if (total_audio_routes > 0) {
    for (int i=0;i<total_audio_routes;i++) {
      if (audio_routing_stack[i].src_id != UNDEFINED) {
        Serial.print(" Src ID: ");
        Serial.println((int) audio_routing_stack[i].src_id, HEX);
        Serial.print("  Src Node Indx: ");
        Serial.println((int) audio_routing_stack[i].src_node_indx, HEX);
        Serial.print(" Dest ID: ");
        Serial.println((int) audio_routing_stack[i].dest_id, HEX);
        Serial.print("  Dest Node Indx: ");
        Serial.println((int) audio_routing_stack[i].dest_node_indx, HEX);
        Serial.println();
      }
    }
  } else {
    Serial.println(" No audio routes in canvas");
  }

  Serial.println("Control routing table:");

  if (total_control_routes > 0) {
    for (int i=0;i<total_control_routes;i++) {
      if (audio_routing_stack[i].src_id != UNDEFINED) {
        Serial.print(" Src ID: ");
        Serial.println((int) control_routing_stack[i].src_id, HEX);
        Serial.print("  Src Node Indx: ");
        Serial.println((int) control_routing_stack[i].src_node_indx, HEX);
        Serial.print(" Dest ID: ");
        Serial.println((int) control_routing_stack[i].dest_id, HEX);
        Serial.print("  Dest Node Indx: ");
        Serial.println((int) control_routing_stack[i].dest_node_indx, HEX);
        Serial.println();
      }
    }
  } else {
    Serial.println(" No control routes in canvas");
  }


}

/**
 * @brief    Utility function to print the parameter tables
 */
void fx_canvas::print_param_tables() {
  char buf[64];



  Serial.println("Parameter tables:");

  if (total_instances <= 1) {
    Serial.println(" There are no effect instances in this canvas so there are no parameters");
    return;
  }

  for (int i=1;i<total_instances;i++) {
    if (instance_stack[i].address == NULL) {
      sprintf(buf, "Null pointer encoundered for instance %d", i); Serial.println(buf);
    } else {

      if (instance_stack[i].type == FX_AMPLITUDE_MODULATOR) {
        sprintf(buf, "AMP MODULATOR (instance %d)", i); Serial.println(buf);
        fx_amplitude_mod * effect = (fx_amplitude_mod *) instance_stack[i].address; 
        effect->print_params();
      }

      if (instance_stack[i].type == FX_BIQUAD_FILTER) {
        sprintf(buf, "BIQUAD (instance %d)", i); Serial.println(buf);
        fx_biquad_filter * effect = (fx_biquad_filter *) instance_stack[i].address; 
        effect->print_params();
      }

      if (instance_stack[i].type == FX_CLIPPER) {
        sprintf(buf, "Clipper (instance %d)", i); Serial.println(buf);
        fx_clipper * effect = (fx_clipper *) instance_stack[i].address; 
        effect->print_params();
      }

      if (instance_stack[i].type == FX_COMPRESSOR) {
        sprintf(buf, "Compressor (instance %d)", i); Serial.println(buf);
        fx_compressor * effect = (fx_compressor *) instance_stack[i].address; 
        effect->print_params();
      }


      if (instance_stack[i].type == FX_DELAY) {
        sprintf(buf, "DELAY (instance %d)", i); Serial.println(buf);
        fx_delay * effect = (fx_delay *) instance_stack[i].address; 
        effect->print_params();
      }

      if (instance_stack[i].type == FX_ENVELOPE_TRACKER) {
        sprintf(buf, "ENVELOPE TRACKER (instance %d)", i); Serial.println(buf);
        fx_envelope_tracker * effect = (fx_envelope_tracker *) instance_stack[i].address; 
        effect->print_params();
      }


      if (instance_stack[i].type == FX_GAIN) {
        sprintf(buf, "GAIN (instance %d)", i); Serial.println(buf);
        fx_gain * effect = (fx_gain *) instance_stack[i].address; 
        effect->print_params();
      }

      if (instance_stack[i].type == FX_MIXER_2) {
        sprintf(buf, "MIXER x 2 (instance %d)", i); Serial.println(buf);
        fx_mixer_2 * effect = (fx_mixer_2 *) instance_stack[i].address; 
        effect->print_params();
      }      
  
      if (instance_stack[i].type == FX_MIXER_3) {
        sprintf(buf, "MIXER x 3 (instance %d)", i); Serial.println(buf);
        fx_mixer_3 * effect = (fx_mixer_3 *) instance_stack[i].address; 
        effect->print_params();
      }      

      if (instance_stack[i].type == FX_MIXER_4) {
        sprintf(buf, "MIXER x 4 (instance %d)", i); Serial.println(buf);
        fx_mixer_4 * effect = (fx_mixer_4 *) instance_stack[i].address; 
        effect->print_params();
      }      

      if (instance_stack[i].type == FX_PHASE_SHIFTER) {
        sprintf(buf, "PHASE SHIFTER (instance %d)", i); Serial.println(buf);
        fx_phase_shifter * effect = (fx_phase_shifter *) instance_stack[i].address; 
        effect->print_params();
      }

      if (instance_stack[i].type == FX_PITCH_SHIFT) {
        sprintf(buf, "PITCH SHIFT (instance %d)", i); Serial.println(buf);
        fx_pitch_shift * effect = (fx_pitch_shift *) instance_stack[i].address; 
        effect->print_params();
      }

      if (instance_stack[i].type == FX_RING_MOD) {
        sprintf(buf, "RING MODULATOR (instance %d)", i); Serial.println(buf);
        fx_ring_mod * effect = (fx_ring_mod *) instance_stack[i].address; 
        effect->print_params();
      }

      if (instance_stack[i].type == FX_SLICER) {
        sprintf(buf, "SLICER (instance %d)", i); Serial.println(buf);
        fx_slicer * effect = (fx_slicer *) instance_stack[i].address; 
        effect->print_params();
      }

      if (instance_stack[i].type == FX_LOOPER) {
        sprintf(buf, "LOOPER (instance %d)", i); Serial.println(buf);
        fx_looper * effect = (fx_looper *) instance_stack[i].address; 
        effect->print_params();
      }

      if (instance_stack[i].type == FX_OSCILLATOR) {
        sprintf(buf, "OSCILLATOR (instance %d)", i); Serial.println(buf);
        fx_oscillator * effect = (fx_oscillator *) instance_stack[i].address; 
        effect->print_params();
      }


      if (instance_stack[i].type == FX_VARIABLE_DELAY) {
        sprintf(buf, "VARIABLE DELAY (instance %d)", i); Serial.println(buf);
        fx_variable_delay * effect = (fx_variable_delay *) instance_stack[i].address; 
        effect->print_params();
      }

      else {
        fx_effect * effect = (fx_effect *) instance_stack[i].address;
        effect->print_params();
      }
    }
  }
}

/************************************************************************
 *
 *                        EFFECTS FUNCTIONS
 *
 ***********************************************************************/


/**
 * @brief      Looks up the index of a given node in the node stack for this effect
 *
 * @param      node        The node to look up
 * @param      node_index  The node index that was looked up (output)
 *
 * @return     True if found, false if not
 */
bool fx_effect::get_audio_node_index(fx_audio_node * node, uint8_t * local_node_index) {

  for (int i=0;i<MAX_NODES_PER_FX;i++) {

    if (node == audio_node_stack[i]) {
      *local_node_index = i;
      
      // save in instance
      node_index = i;
      return true;
    }
  }
  return false;
}

bool fx_effect::get_control_node_index(fx_control_node * node, uint8_t * local_node_index) {
  

  for (int i=0;i<MAX_NODES_PER_FX;i++) {
  
    if (node == control_node_stack[i]) {
      *local_node_index = i;
      
      // save in instance
      node_index = i;
      return true;
    }
  }
  return false;
}


uint16_t * fx_effect::serialize_params(uint16_t * serialized_params, uint16_t * size) {

  char buf[64];

  sprintf(buf,"Serializing parameters for : %s", effect_name); Serial.println(buf);

  // serialize instance data
  int indx = 0;

  uint32_t part_32;
  uint16_t part_16;
  uint8_t part_8;
  
  for (int i=0;i<total_params;i++) {
   
    if (param_stack_types[i] == T_BOOL) {
     // Serial.println(" : bool");
      part_16 = * (uint8_t *) param_stack[i];
      serialized_params[indx++] = part_16;
    }
    else if (param_stack_types[i] == T_INT16) {
      //Serial.println(" : int16");
      //Serial.println((int)param_stack[i],HEX);
      serialized_params[indx++] = (uint16_t) (* (uint16_t *) param_stack[i]);
    }
    else if (param_stack_types[i] == T_INT32) {
      //Serial.println(" : int32");
      part_32 = * (uint32_t *) param_stack[i];
      serialized_params[indx++] = (uint16_t)((* (uint32_t *) param_stack[i]) >> 16);
      serialized_params[indx++] = (uint16_t)((* (uint32_t *) param_stack[i]) & 0xFFFF);
    }
    else if (param_stack_types[i] == T_FLOAT) {
      //Serial.println(" : float");
      part_32 = * (uint32_t *) param_stack[i];
      serialized_params[indx++] = (uint16_t) (part_32 >> 16);
      serialized_params[indx++] = (uint16_t) (part_32 & 0xFFFF);
    }   

    //sprintf(buf,"  %#08x - %d", param_stack[i], (int) param_stack_types[i]); Serial.println(buf);

  }
  *size = indx;
  Serial.println("  ------");

  for (int i=0;i<indx;i++) {
    //sprintf(buf,"  %#04x, [%#08x] -> %#04x - %d", serialized_params[i], param_stack[i], * (uint16_t *) param_stack[i], (int) param_stack_types[i]); Serial.println(buf);
    sprintf(buf,"  %#04x", serialized_params[i]); Serial.println(buf);
  }
  Serial.println("Complete");
  //sprintf(buf, "Bool: %d" , (int) sizeof(bool)); Serial.println(buf);
}

/**
 * @brief      Checks to see if a float parameter has been updated
 * 
 * This function also applies hysteresis 
 *
 * @param      param       The parameter
 * @param      param_last  The parameter last
 *
 * @return     True if updated, false if not
 */
bool  fx_effect::float_param_updated( float * param, float * param_last, float threshold ) {
  
  bool different;
  if (abs(*param - *param_last) > threshold) {
    different = true;
  } else {
    different = false;
  }

  *param_last = *param;

  return different;

}

/**
 * @brief      Checks to see if a bool parameter has been updated
 *
 * @param      param       The parameter
 * @param      param_last  The parameter last
 *
 * @return     True if updated, false if not
 */
bool  fx_effect::bool_param_updated( bool * param, bool * param_last ) {
  bool different = false;
  if (*param != *param_last) {
    different = true;
  }
  *param_last = *param;
  return different;
}    


void  fx_effect::print_params(void) {
  Serial.println(" No print function declared for this effect");
}

bool  fx_effect::service(void) {
  Serial.println(" No service function declared for this effect");  
  return false;
}