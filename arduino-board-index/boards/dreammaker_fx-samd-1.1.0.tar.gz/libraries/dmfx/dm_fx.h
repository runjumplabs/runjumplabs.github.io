 /**
  * afx.h
  * 
  * Audio Effects Library
  */
#ifndef DM_FX_H
#define DM_FX_H

#include "Arduino.h"
#include <SPI.h>
#include <Wire.h>

#include "dm_fx_effects_defines.h"


#define API_VERSION_MAJ     (1)
#define API_VERSION_MIN     (1)



#ifndef PI2
#define PI2 (3.14159265358979323846*2)
#endif 


#define MAX_INSTANCES                 (20)
#define MAX_ROUTES                    (50)
#define MAX_NODES_PER_FX              (10)
#define MAX_PARMS_PER_FX              (64)
#define MAX_NODE_NAME                 (32)
#define UNDEFINED                     (0xff)

// Frame constants 
#define FRAME_HEADER_1                (0x80FD)
#define FRAME_HEADER_2                (0x80FE)
#define FRAME_TERMINATOR              (0x80FF)

// Protocol
#define HEADER_INSTANCE_BLOCK         (0x8001)
#define HEADER_AUDIO_ROUTING_BLOCK    (0x8002)
#define HEADER_CONTROL_ROUTING_BLOCK  (0x8003)
#define HEADER_PARAMETER_BLOCK        (0x8004)
#define HEADER_SINGLE_PARAMETER       (0x8005)
#define HEADER_SET_BYPASS             (0x8006)
#define HEADER_GET_STATUS             (0x8007)


#define PIN_FOOTSW_1                  (0)
#define PIN_FOOTSW_2                  (1)
#define PIN_FOOTSW_LED_1              (2)
#define PIN_FOOTSW_LED_2              (3)
#define PIN_USR_PB                    (4)
#define PIN_ARD_LED                   (5)
#define SPI_SS_PIN                    (47) 
#define PIN_DSP_RESET                 (6)


class fx_effect;
class fx_canvas;

typedef enum {
  SPI_RX_WAITING,
  SPI_RX_HEADER_1_RX,
  SPI_RX_RECEIVING,
  SPI_RX_FRAME_READY
} SPI_RX_STATE;

typedef enum {
  NODE_IN,
  NODE_OUT
} NODE_DIRECTION;

typedef struct {
  uint8_t id;
  EFFECT_TYPE type;
  void * address;
} FX_INSTANCE;

typedef struct {
  uint8_t src_id;
  uint8_t src_node_indx;
  uint8_t dest_id;
  uint8_t dest_node_indx;
} AUDIO_ROUTE;

typedef struct {
  uint8_t src_id;
  uint8_t src_node_indx;
  uint8_t src_param_id;
  uint8_t dest_id;
  uint8_t dest_node_indx;
  uint8_t dest_param_id;
  float scale;
  float offset;
  CTRL_NODE_TYPE type;
} CTRL_ROUTE;

// Current status of the DSP
typedef struct {
  bool      valid;
  uint8_t   firmware_maj;
  uint8_t   firmware_min;
  bool      canvas_running;
  float     loading_percentage;
} DSP_STATUS;
extern DSP_STATUS   dsp_status;

char * get_effect_type(EFFECT_TYPE t);

/************************************************************************
 * NODES 
 ***********************************************************************/

/**
 * @brief      Class for effects audio node.
 * 
 * Audio nodes are audio inputs and outputs.  Audio nodes can exist on an 
 * effect (i.e. effect inputs and outputs).  Audio nodes can also exist on the
 * canvas (i.e. ADC and DAC channels that are part of the hardware).
 */
class fx_audio_node {
  
  friend class fx_canvas;

  protected:
    fx_effect      * parent_effect;
    fx_canvas      * parent_canvas;

  public:

    NODE_DIRECTION node_direction;    
    bool           connected;
    char           node_name[MAX_NODE_NAME];

    // Audio nodes that are part of the effect
    fx_audio_node(NODE_DIRECTION dir, const char * name, fx_effect * p) {
      node_direction = dir;
      strcpy(node_name, name);
      parent_effect = p;
      parent_canvas = NULL;
      connected = false;
    }

    // Audio nodes that are part of the canvas (i.e. ADCs, DACs)
    fx_audio_node(NODE_DIRECTION dir, const char * name, fx_canvas * p) {
      node_direction = dir;
      strcpy(node_name, name);
      parent_canvas = p;
      parent_effect = NULL;
      connected = false;
    }    
  
};

/**
 * @brief      Class for effects control node.
 * 
 * Control nodes are controller inputs and outputs.  Control nodes can exist on 
 * effects like an amplitude measurement outupt or delay lenght input.  They can
 * also exist in the canvas like a MIDI input or a POT connected to an ADC.
 * 
 * Control nodes are updated at the block level
 */
class fx_control_node {

  friend class fx_canvas;

  protected:
    fx_effect      * parent_effect;
    fx_canvas      * parent_canvas;    

  public:
    uint8_t        param_id;
    NODE_DIRECTION node_direction;
    CTRL_NODE_TYPE node_type;
    char           node_name[MAX_NODE_NAME];

    bool           connected;

    // Control nodes that are part of effects
    fx_control_node(NODE_DIRECTION dir, CTRL_NODE_TYPE type, const char * name, fx_effect * p, uint8_t ctrl_param_id) {
      param_id = ctrl_param_id;
      node_direction = dir;
      node_type = type;
      strcpy(node_name, name);
      parent_effect = p;
      parent_canvas = NULL;
      connected = false;  
    }

    // Control nodes that are part of the canvas (i.e. POTs, MIDI, etc.)
    fx_control_node(NODE_DIRECTION dir, CTRL_NODE_TYPE type, const char * name, fx_canvas * p, uint8_t ctrl_param_id) {
      param_id = ctrl_param_id;
      node_direction = dir;
      node_type = type;
      strcpy(node_name, name);
      parent_canvas = p;
      parent_effect = NULL;
      connected = false;
    }    
};

class fx_pot_buddy {


  private:
    bool  first_read;
    bool  changed;
    float avg_val;
    float val_last;
    int   avg_ptr;
    int   pin_number;
    float coeff;

  public:

    float val;

    float read_pot() {
      
      changed = false;

      int val_int;
      if (pin_number == 0) val_int = analogRead(A0);
      else if (pin_number == 1) val_int = analogRead(A1);
      else if (pin_number == 2) val_int = analogRead(A2);
      else {
        val_int = 0;
      }
      float valf = (1.0/1023.0) * (float) val_int;

      if (abs(valf-val_last) > 0.02) {
        changed = true;
      } else if (first_read) {
        changed = true;
        first_read = false;
      }

      val_last += coeff * (valf - val_last);     
      val = val_last;

    }


    fx_pot_buddy(int pin) {
      coeff = 0.2;
      pin_number = pin;

      if (pin_number == 0) val = analogRead(A0);
      else if (pin_number == 1) val = analogRead(A1);
      else if (pin_number == 2) val = analogRead(A2);
      else {
        val = 0;
      }
      val_last = (1.0/1023.0) * (float) val;
      val = val_last;
      first_read = true;
    }

    bool has_changed(void) {
      bool return_val = changed;
      changed = false;
      return return_val;
    }

};


/**********************************************************************
 * CANVAS
 *********************************************************************/

class fx_canvas {

  private:

    // Has the system been initialized
    bool        initialized;
    bool        valid_audio_routes;
    bool        valid_control_routes;
    bool        debug_mode;

    uint32_t    last_service_ts;

    DSP_STATUS * status;

#if 0
    uint16_t    spi_data_block[MAX_SPI_BLOCK_SIZE+1];
    uint16_t    spi_data_block_size;
#endif 

    // All effect instances in canvas
    FX_INSTANCE instance_stack[MAX_INSTANCES];
    int         total_instances;

    // All audio routes between effects in cancas
    AUDIO_ROUTE audio_routing_stack[MAX_ROUTES];
    int         total_audio_routes;

    // All control routes between effects in cancas
    CTRL_ROUTE  control_routing_stack[MAX_ROUTES];
    int         total_control_routes;

    // Does this canvas have a valid topology
    bool        valid_canvas;   

    // Adds a new route
    bool    add_audio_route_to_stack(uint8_t src_id, uint8_t src_node_indx, uint8_t dest_id, uint8_t dest_node_indx);
    bool    add_control_route_to_stack(uint8_t src_id, 
                                            uint8_t src_node_indx, 
                                            uint8_t src_param_id, 
                                            uint8_t dest_id,                                             
                                            uint8_t dest_node_indx,
                                            uint8_t dest_param_id, 
                                            float scale,
                                            float offset,
                                            CTRL_NODE_TYPE type);
    
    // Transmit all parameters from all effects
    void    spi_transmit_all_params(void);
    void    spi_transmit_params(uint16_t node_index);
    void    spi_transmit_audio_routing_stack(void);
    void    spi_transmit_control_routing_stack(void);
    void    spi_transmit_instance_stack(void);


    // Returns the index in the node index for this effect 
    bool    get_audio_node_index(fx_audio_node * node, uint8_t * node_index);
    bool    get_control_node_index(fx_control_node * node, uint8_t * node_index);

    fx_audio_node sys_input_instr_l;
    fx_audio_node sys_input_instr_r;
    fx_audio_node sys_output_amp_l;
    fx_audio_node sys_output_amp_r;
    fx_audio_node sys_input_mic_l;
    fx_audio_node sys_input_mic_r;
    

  protected:
    fx_audio_node   * audio_node_stack[2];
    fx_control_node * control_node_stack[2];

  public:

    friend class fx_effect;

    fx_pot_buddy  pot_0;
    fx_pot_buddy  pot_1;
    fx_pot_buddy  pot_2;

    fx_audio_node * instr_in;   // Alias
    fx_audio_node * instr_in_l;
    fx_audio_node * instr_in_r;
    fx_audio_node * amp_out;    // Alias
    fx_audio_node * amp_out_l;
    fx_audio_node * amp_out_r;
    fx_audio_node * mic_in_l;
    fx_audio_node * mic_in_r;

    fx_canvas():

      // Set i/o nodes for canvas
      pot_0(0),
      pot_1(1),
      pot_2(2),
      sys_input_instr_l(NODE_OUT, "instr_in_l", this), 
      sys_input_instr_r(NODE_OUT, "instr_in_r", this), 
      sys_output_amp_l(NODE_IN, "amp_out_l", this),
      sys_output_amp_r(NODE_IN, "amp_out_r", this),
      sys_input_mic_l(NODE_IN, "mic_in_l", this),
      sys_input_mic_r(NODE_IN, "mic_in_r", this) {

      // Audio routing nodes
      instr_in = &sys_input_instr_l;    // Alias
      instr_in_l = &sys_input_instr_l;
      instr_in_r = &sys_input_instr_r;
      amp_out = &sys_output_amp_l;      // Alias
      amp_out_l = &sys_output_amp_l;
      amp_out_r = &sys_output_amp_r;
      mic_in_l = &sys_input_mic_l;
      mic_in_r = &sys_input_mic_r;


      // Add to node stack
      audio_node_stack[0] = instr_in_l;
      audio_node_stack[1] = amp_out_l;
      /*
      audio_node_stack[2] = instr_in_r;
      audio_node_stack[3] = amp_out_r;
      audio_node_stack[4] = mic_in_l;
      audio_node_stack[5] = mic_in_r;
      */

      // Add canvas as instance 0
      total_instances = 1;
      instance_stack[0].id = 0;
      instance_stack[0].type = CANVAS;

      // Init the remaining slots in the instance stack
      for (int i=1;i<MAX_INSTANCES;i++) {
        instance_stack[i].id = UNDEFINED;
        instance_stack[i].address = NULL;       
        instance_stack[i].type = FX_UNDEFINED; 
      }

      // Init the slots in the audio and control routing stacks
      total_audio_routes = 0;
      total_control_routes = 0;
      for (int i=0;i<MAX_ROUTES;i++) {
        audio_routing_stack[i].src_id = UNDEFINED;
        audio_routing_stack[i].src_node_indx = UNDEFINED;       
        audio_routing_stack[i].dest_id = UNDEFINED; 
        audio_routing_stack[i].src_node_indx = UNDEFINED;       

        control_routing_stack[i].src_id = UNDEFINED;
        control_routing_stack[i].src_node_indx = UNDEFINED;       
        control_routing_stack[i].dest_id = UNDEFINED; 
        control_routing_stack[i].src_node_indx = UNDEFINED;            
      }    

      // Set valid canvas to false
      valid_canvas = false;

      // Set initialized to false      
      initialized = false;

      // Set routes valid to false 
      valid_audio_routes = false;
      valid_control_routes = false;

      status = &dsp_status;

      // Set last service timetamp
      last_service_ts = millis();

    }


    // Initialize
    void    init(bool debug_mode);
    void    init();

    // Services any SPI transactions that need to happen
    void    spi_service(void);
    void    spi_get_status(void);
    void    spi_transmit_param(EFFECT_TYPE instance_type, uint32_t instance_id, PARAM_TYPES param_type, uint8_t param_id, void * value);

    // Routine service loop
    void  service(void) {

      // Run the service loop ~30 times / second
      if (millis() < last_service_ts + 33) return;
      last_service_ts = millis();

      // read pots and see if they have changed 
      pot_0.read_pot();
      pot_1.read_pot();
      pot_2.read_pot();

      // If any telemetry data came in from the SHARC, pass it to USB Serial if connected
      if (Serial && debug_mode) {
        while (Serial1.available() > 0) {
          // read the incoming byte:
          Serial.write(Serial1.read());
        }
      }

      // Get status data from the DSP
      spi_get_status();

      // Service any parameter updates
      spi_service();

    }

    void    spi_transmit_bypass(uint16_t bypass_state);
    void    bypass_fx(void) {
      spi_transmit_bypass((uint16_t) 0);
    }
    void    enable_fx(void) {
      spi_transmit_bypass((uint16_t) 1);
    }



    // Parameter serice function
    void    parameter_service(void);

    // Route audio and control links
    bool    route_audio(fx_audio_node * out, fx_audio_node * in);
    bool    route_control(fx_control_node * src, fx_control_node * dest, float scale, float offset);

    // Compiles the canvas / downloads to DSP
    bool    run(void);

    const char * get_name() {
        return "canvas";
    }

    // Utility functions to print the instance and routing stack
    void print_instance_stack(void);
    void print_routing_table(void);
    void print_param_tables(void);
};


extern fx_canvas pedal;



/**********************************************************************
 * EFFECTS
 *********************************************************************/
class fx_effect {
  
  protected:

    friend fx_canvas;


    EFFECT_TYPE     type;

    // input / output node stack (audio and control)
    fx_audio_node * audio_node_stack[MAX_NODES_PER_FX];
    int             total_audio_nodes;
    fx_control_node * control_node_stack[MAX_NODES_PER_FX];
    int             total_control_nodes;

    // Parameter stack
    void            * param_stack[MAX_PARMS_PER_FX];
    PARAM_TYPES     param_stack_types[MAX_PARMS_PER_FX];

    // total number of parameters that this effect has
    int             total_params;

    // Universal effect parameters
    bool            param_enabled;

    fx_audio_node   node_input;
    fx_audio_node   node_output;
    fx_control_node node_enabled;

    int             node_index;
    fx_canvas       * parent_canvas;
    uint8_t         instance_id;

    // Set when there are new parameters to send down to DSP
    bool            updated_parameters;


    
    bool get_audio_node_index(fx_audio_node * node, uint8_t * local_node_index);
    bool get_control_node_index(fx_control_node * node, uint8_t * local_node_index);

    uint16_t * serialize_params(uint16_t * serialized_params, uint16_t * size);
    bool  float_param_updated( float * param, float * param_last, float threshold );
    bool  bool_param_updated( bool * param, bool * param_last );


  public:

    friend class fx_canvas;

    // String name of current effect    
    char  effect_name[32];
    
    // Constructor
    fx_effect() : 
      node_input(NODE_IN, "input", this), 
      node_output(NODE_OUT, "output", this),
      node_enabled(NODE_IN, NODE_BOOL, "enabled", this, FX_PARAM_ID_ENABLED) {

        // Set up default audio nodes
        total_audio_nodes = 0;
        audio_node_stack[total_audio_nodes++] = &node_input;
        audio_node_stack[total_audio_nodes++] = &node_output;

        // Set up default control nodes
        total_control_nodes = 0;
        control_node_stack[total_control_nodes++] = &node_enabled;
        
        // Set up initial parameter stack
        param_enabled = true;
        param_stack[0] = &param_enabled;
        param_stack_types[0] = T_BOOL;
        total_params = 1;

        // Node index has not been assigned
        node_index = 0;

        // No parameters to update an init
        updated_parameters = false;

        // Set instance ID to 0xFF (meaning it hasn't been routed/placed yet)
        instance_id = 0xFF;

    }

    bool  service(void);
    void  print_params(void);

    const char * get_name() {
        return effect_name;
    }

    EFFECT_TYPE get_type() {
      return type;
    }

    void  enable(void) {
      param_enabled = true; 
    }

    void  bypass(void) {
      param_enabled = false; 
    }

    void print_ctrl_node_status(fx_control_node * t) {
      char buf[64];
      sprintf(buf," + [%s] %s: ", (t->node_direction==NODE_IN?"ctrl-in":"ctrl-out"), t->node_name);  Serial.print(buf);
      if (t->connected) {
        Serial.println("routed");
      } else {
        Serial.println("not routed");
      }
    }

    void print_audio_node_status(fx_audio_node * t) {
      char buf[64];
      sprintf(buf," * [%s] %s: ", (t->node_direction==NODE_IN?"audio-in":"audio-out"), t->node_name);  Serial.print(buf);
      if (t->connected) {
        Serial.println("routed");
      } else {
        Serial.println("not routed");
      }
    }

    void print_parameter( void * val, char * name, PARAM_TYPES type) {
      char buf[64];
      if (type == T_FLOAT) {
        sprintf(buf," %s: %.2f", name, *(float*) val);  Serial.println(buf);
      } else if (type == T_BOOL) {
        sprintf(buf," %s: %s", name, *(bool*) val?"true":"false");  Serial.println(buf);
      } else if (type == T_INT16) {
        sprintf(buf," %s: %u", name, *(uint16_t*) val);  Serial.println(buf);
      }
    }
};


#include "dm_fx_amplitude_modulator.h"
#include "dm_fx_biquad_filter.h"
#include "dm_fx_clipper.h"
#include "dm_fx_compressor.h"
#include "dm_fx_delay.h"
#include "dm_fx_envelope_tracker.h"
#include "dm_fx_gain.h"
#include "dm_fx_instr_synth.h"
#include "dm_fx_looper.h"
#include "dm_fx_mixers.h"
#include "dm_fx_oscillators.h"
#include "dm_fx_phase_shifter.h"
#include "dm_fx_pitch_shift.h"
#include "dm_fx_ring_modulator.h"
#include "dm_fx_shaper.h"
#include "dm_fx_slicer.h"
#include "dm_fx_variable_delay.h"

#endif // DM_FX_H