/**
 * Copyright (c) 2019 Run Jump Labs LLC.  All right reserved. 
 * 
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either  
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details. 
 * 
 * The GNU Lesser General Public License can be found here:
 * https://www.gnu.org/licenses/lgpl-3.0.en.html
 * 
 * Or write to the Free Software Foundation, Inc., 
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#ifndef DM_FX_BIQUAD_FILTER_H
#define DM_FX_BIQUAD_FILTER_H

/**
 * @brief      Effect: Biquad filter for implementing various types of filters (low
 *             pass, high pass, band pass, etc.)
 */
class fx_biquad_filter: public fx_effect {

  private:

    // Parameters
    // important safety tip - don't put 8-bit enum types together as they need to exist on 16 or 32-bit memory boundaries
    BIQUAD_FILTER_TYPE			param_type;
    float param_freq;
    float param_q;
    float param_gain;
    EFFECT_TRANSITION_SPEED param_speed;

	  // Control nodes
	  fx_control_node node_ctrl_freq;
	  fx_control_node node_ctrl_q;
	  fx_control_node node_ctrl_gain;

    void init(void) {

	    // Set class
	    type = FX_BIQUAD_FILTER;

	    // Set name
	    strcpy(effect_name, "biquad filter");


	    // Assign programmable node names
	    input = &node_input;
	    output = &node_output;
	    
			// Initialize parameter stack
	    int indx = 1;
	    param_stack[indx] = &param_type;
	    param_stack_types[indx++] = T_INT16;
	    param_stack[indx] = &param_speed;
	    param_stack_types[indx++] = T_INT16;
	    param_stack[indx] = &param_freq;
	    param_stack_types[indx++] = T_FLOAT;
	    param_stack[indx] = &param_q;
	    param_stack_types[indx++] = T_FLOAT;
	    param_stack[indx] = &param_gain;
	    param_stack_types[indx++] = T_FLOAT;
	    total_params = indx;    

	    // Add addititonal nodes to the control stack
	    control_node_stack[total_control_nodes++] = &node_ctrl_freq;
	    control_node_stack[total_control_nodes++] = &node_ctrl_q;
	    control_node_stack[total_control_nodes++] = &node_ctrl_gain;

	    // Assign controls
	    freq = &node_ctrl_freq;
	    q = &node_ctrl_q;
	    gain = &node_ctrl_gain;
    }



 public:

	/**
	 * Audio routing node: primary audio input
	 */
  fx_audio_node * input;

  /**
   * Audio routing node: primary audio output
   */
  fx_audio_node * output;

  /**
   * Control routing node: center/critical frequency of the filter
   */
  fx_control_node * freq;


  /**
   * Control routing node: width of the filter
   */
  fx_control_node * q;


  /**
   * Control routing node: gain of the filter (used in shelving filters)
   */
  fx_control_node * gain;    


	/**
	 * @brief      Basic constructor for biquad filter
	 *
	 * @param[in]  filt_freq   The filter critical/cutoff frequency
	 * @param[in]  filt_width  The filter width, see BIQUAD_FILTER_WIDTH for options
	 * @param[in]  filt_type   The filter type, see BIQUAD_FILTER_TYPE for options
	 */
  fx_biquad_filter(float filt_freq, BIQUAD_FILTER_WIDTH filt_width, BIQUAD_FILTER_TYPE filt_type) :
    node_ctrl_freq(NODE_IN, NODE_FLOAT, "node_ctrl_freq", this, FX_BIQUAD_PARAM_ID_FREQ),
    node_ctrl_q(NODE_IN, NODE_FLOAT, "node_ctrl_q", this, FX_BIQUAD_PARAM_ID_Q),
    node_ctrl_gain(NODE_IN, NODE_FLOAT, "node_ctrl_gain", this, FX_BIQUAD_PARAM_ID_GAIN) {

    // Set parameters
    param_freq = filt_freq;
    switch (filt_width) {
    	case FILTER_WIDTH_VERY_NARROW:
    				param_q = 8.0;
    				break;
    	case FILTER_WIDTH_NARROW:
    				param_q = 4.0;
    				break;
    	case FILTER_WIDTH_MEDIUM:
    				param_q = 1.0;
    				break;
    	case FILTER_WIDTH_WIDE:
    				param_q = 0.7071;
    				break;
    	case FILTER_WIDTH_VERY_WIDE:
    				param_q = 0.5;
    				break;
    }
    param_gain = 0.0;    
    param_type = filt_type; 
    param_speed = TRANS_MED;

    init();

  } 


  /**
   * @brief      Advanced constructor for biquad filter
   *
   * @param[in]  filt_freq    The filter critical/cutoff frequency
   * @param[in]  filt_width   The filter Q factor
   * @param[in]  filter_gain  The filter gain in dB
   * @param[in]  filt_type    The filter type, see BIQUAD_FILTER_TYPE for
   *                          options
   * @param[in]  trans_speed  The transaction speed when new filter parameters
   *                          are suppliued, see EFFECT_TRANSITION_SPEED for
   *                          options
   */
  fx_biquad_filter(float filt_freq, float filt_width, float filter_gain, BIQUAD_FILTER_TYPE filt_type, EFFECT_TRANSITION_SPEED trans_speed) :
    node_ctrl_freq(NODE_IN, NODE_FLOAT, "node_ctrl_freq", this, FX_BIQUAD_PARAM_ID_FREQ),
    node_ctrl_q(NODE_IN, NODE_FLOAT, "node_ctrl_q", this, FX_BIQUAD_PARAM_ID_Q),
    node_ctrl_gain(NODE_IN, NODE_FLOAT, "node_ctrl_gain", this, FX_BIQUAD_PARAM_ID_GAIN) {

    // Set parameters
    param_freq = filt_freq;
    param_q = filt_width;
    param_gain = filter_gain;    
    param_type = filt_type; 
    param_speed = trans_speed;

    init();

  } 

  /**
   * @brief      Enable the biquad filter (it is enabled by default)
   */
  void enable() {
    param_enabled = true; 
    parent_canvas->spi_transmit_param(FX_BIQUAD_FILTER, instance_id, T_BOOL, FX_BIQUAD_PARAM_ID_ENABLED, (void *) &param_enabled);
  }

  /**
   * @brief      Bypass the biquad filter (will just pass clean audio through)
   */
  void bypass() {
    param_enabled = false; 
    parent_canvas->spi_transmit_param(FX_BIQUAD_FILTER, instance_id, T_BOOL, FX_BIQUAD_PARAM_ID_ENABLED, (void *) &param_enabled);
  }  

  /**
   * @brief      Sets a new cutoff/critical frequency (Hz). 
   *
   * @param[in]  freq  The new center frequency for the filter in Hz (must be lower than 24000.0)
   */
  void set_freq(float freq) { 

    // If this node is being controlled by a controller, don't allow a direct write to it
    if (node_ctrl_freq.connected) {
      return; 
    }

    param_freq = freq; 
    parent_canvas->spi_transmit_param(FX_BIQUAD_FILTER, instance_id, T_FLOAT, FX_BIQUAD_PARAM_ID_FREQ, &param_freq);
  }

  /**
   * @brief      Sets a new Q factor for the filter.  For more information on Q
   *             factor, read this: https://en.wikipedia.org/wiki/Q_factor
   *
   * @param[in]  q     The Q factor (must be between 0.01 and 100.0)
   */
  void set_q(float q) { 
    if (node_ctrl_q.connected) {
      return; 
    }

    param_q = q; 
    parent_canvas->spi_transmit_param(FX_BIQUAD_FILTER, instance_id, T_FLOAT, FX_BIQUAD_PARAM_ID_Q, &param_q);
  }    

  /**
   * @brief      Sets the filter gain.  This is only used in shelving filters
   *
   * @param[in]  gain  The gain in dB
   */
  void set_gain(float gain) { 
    if (node_ctrl_gain.connected) {
      return; 
    }

    param_gain = gain; 
    parent_canvas->spi_transmit_param(FX_BIQUAD_FILTER, instance_id, T_FLOAT, FX_BIQUAD_PARAM_ID_GAIN, &param_gain);
  }   

  /**
   * @brief      Print the parameters for this effect
   */
  void  print_params(void) {

		// void print_parameter( void * val, char * name, PARAM_TYPES type)
		Serial.println("Parameters:");
    print_parameter( &param_enabled, "Enabled", T_BOOL );
    print_parameter( &param_freq, "Frequency (Hz)", T_FLOAT );
    print_parameter( &param_q, "Width/Q", T_FLOAT );
		print_parameter( &param_gain, "Gain (db)", T_FLOAT );

    Serial.println("Control Routing:");      
    print_ctrl_node_status(&node_ctrl_freq);
    print_ctrl_node_status(&node_ctrl_q);
    print_ctrl_node_status(&node_ctrl_gain);

    Serial.println("Audio Routing:");      
    print_audio_node_status(&node_input);
    print_audio_node_status(&node_output);

    Serial.println();
  }    
};
#endif 	// DM_FX_BIQUAD_FILTER_H