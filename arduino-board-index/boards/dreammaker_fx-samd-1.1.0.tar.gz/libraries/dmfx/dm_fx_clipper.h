/**
 * Copyright (c) 2019 Run Jump Labs LLC.  All right reserved. 
 * 
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either  
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details. 
 * 
 * The GNU Lesser General Public License can be found here:
 * https://www.gnu.org/licenses/lgpl-3.0.en.html
 * 
 * Or write to the Free Software Foundation, Inc., 
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 **/
#ifndef DM_FX_CLIPPER_H
#define DM_FX_CLIPPER_H

/**
 * @brief      Effect: Clipper - provides various types of hard and soft clippers for creating different types of distortions
 */
class fx_clipper: public fx_effect {

  private:

    // Parameters
    POLY_CLIP_FUNC 	param_type;
    float 					param_threshold;
    bool  					param_rectify;
    float						param_drive;
    bool						param_upsample;

    // Control nodes
    fx_control_node node_ctrl_threshold;
    fx_control_node node_ctrl_drive;

	  void init(void) {

		    // Set class
		    type = FX_CLIPPER;

		    // Set name
		    strcpy(effect_name, "clipper");


		    // Assign programmable node names
		    input = &node_input;
		    output = &node_output;
		    
				// Initialize parameter stack
		    int indx = 1;
		    param_stack[indx] = &param_threshold;
		    param_stack_types[indx++] = T_FLOAT;
		    param_stack[indx] = &param_type;
		    param_stack_types[indx++] = T_INT16;
		    param_stack[indx] = &param_drive;
		    param_stack_types[indx++] = T_FLOAT;
		    param_stack[indx] = &param_rectify;
		    param_stack_types[indx++] = T_BOOL;
		    param_stack[indx] = &param_upsample;
		    param_stack_types[indx++] = T_BOOL;
		    total_params = indx;    

		    // Add addititonal nodes to the control stack
		    control_node_stack[total_control_nodes++] = &node_ctrl_threshold;
		    control_node_stack[total_control_nodes++] = &node_ctrl_drive;

		    // Assign controls
		    threshold = &node_ctrl_threshold;
		    drive = &node_ctrl_drive;
	    }

 public:

  /**
   * Audio routing node [input]: primary audio input
   */
  fx_audio_node * input;
  
  /**
   * Audio routing node [output]: primary audio output
   */  
  fx_audio_node * output;

  /**
   * Control routing node [input]: clipping threshold (0.0 -> 1.0)
   */
  fx_control_node * threshold;

  /**
   * Control routing node [input]: input drive multiplier before clipper (up to 64.0)
   */
  fx_control_node * drive;


  /**
   * @brief      Basic constructor for the clipper
   *
   * @param[in]  treshold        The treshold
   * @param[in]  drive           The drive
   * @param[in]  signal_rectify  The signal rectify
   * @param[in]  clip_type       The clip type
   */
  fx_clipper(float treshold, float drive, bool signal_rectify, POLY_CLIP_FUNC clip_type) :
    node_ctrl_threshold(NODE_IN, NODE_FLOAT, "node_ctrl_threshold", this, FX_CLIPPER_PARAM_ID_THRESH),
    node_ctrl_drive(NODE_IN, NODE_FLOAT, "node_ctrl_drive", this, FX_CLIPPER_PARAM_ID_IN_DRIVE) {

    // Set parameters
    param_type = clip_type;
    param_threshold = treshold;
    param_rectify = signal_rectify;    
    param_drive = drive; 
    param_upsample = true;

    init();

  } 

  /**
   * @brief      Advanced constructor for the clipper
   *
   * @param[in]  treshold        The treshold
   * @param[in]  drive           The drive
   * @param[in]  signal_rectify  The signal rectify
   * @param[in]  clip_type       The clip type
   * @param[in]  upsample        The upsample
   */
  fx_clipper(float treshold, float drive, bool signal_rectify, POLY_CLIP_FUNC clip_type, bool upsample) :
    node_ctrl_threshold(NODE_IN, NODE_FLOAT, "node_ctrl_threshold", this, FX_CLIPPER_PARAM_ID_THRESH),
    node_ctrl_drive(NODE_IN, NODE_FLOAT, "node_ctrl_drive", this, FX_CLIPPER_PARAM_ID_IN_DRIVE) {

    // Set parameters
    param_type = clip_type;
    param_threshold = treshold;
    param_rectify = signal_rectify;    
    param_drive = drive; 
    param_upsample = upsample;

    init();

  } 

  /**
   * @brief      Enable the clipper (it is enabled by default)
   */
  void enable() {
    param_enabled = true; 
    parent_canvas->spi_transmit_param(FX_CLIPPER, instance_id, T_BOOL, FX_CLIPPER_PARAM_ID_ENABLED, (void *) &param_enabled);
  }

  /**
   * @brief      Bypass the clipper (will just pass clean audio through)
   */
  void bypass() {
    param_enabled = false; 
    parent_canvas->spi_transmit_param(FX_CLIPPER, instance_id, T_BOOL, FX_CLIPPER_PARAM_ID_ENABLED, (void *) &param_enabled);
  }  

  /**
   * @brief      Sets the clipping threshold
   *
   * @param[in]  threshold  The threshold for clipping should be between 0.1 and
   *                        1.0.  A value of 0.1 will provide aggressive clipping where
   *                        as a value of 0.8 will provide more gentle clipping.
   */
  void set_threshold(float new_threshold) { 
    if (node_ctrl_threshold.connected) {
      return; 
    }

    param_threshold = new_threshold; 
    parent_canvas->spi_transmit_param(FX_CLIPPER, instance_id, T_FLOAT, FX_CLIPPER_PARAM_ID_THRESH, &param_threshold);
  }

  /**
   * @brief      Sets the input drive before the clipper
   *
   * @param[in]  drive  The drive a value that the incoming signal will get
   *                    multiplied by before entering the clipper.
   */
  void set_input_drive(float new_drive) { 
    if (node_ctrl_drive.connected) {
      return; 
    }

    param_drive = new_drive; 
    parent_canvas->spi_transmit_param(FX_CLIPPER, instance_id, T_FLOAT, FX_CLIPPER_PARAM_ID_IN_DRIVE, &param_drive);
  }  

  /**
   * @brief      Print the parameters for this effect
   */
  void  print_params(void) {
		Serial.println("Parameters:");
    print_parameter( &param_enabled, "Enabled", T_BOOL );
    print_parameter( &param_threshold, "Clipping threshold", T_FLOAT );
    print_parameter( &param_drive, "Input drive", T_FLOAT );
		print_parameter( &param_rectify, "Rectifying signal", T_FLOAT );
		print_parameter( &param_upsample, "Upsample", T_FLOAT );
		print_parameter( &param_type, "Clipping preset", T_INT16 );

    Serial.println("Control Routing:");      
    print_ctrl_node_status(&node_ctrl_threshold);
    print_ctrl_node_status(&node_ctrl_drive);

    Serial.println("Audio Routing:");      
    print_audio_node_status(&node_input);
    print_audio_node_status(&node_output);

    Serial.println();
  }    
};
#endif  // DM_FX_CLIPPER_H

