/**
 * Copyright (c) 2019 Run Jump Labs LLC.  All right reserved. 
 * 
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either  
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details. 
 * 
 * The GNU Lesser General Public License can be found here:
 * https://www.gnu.org/licenses/lgpl-3.0.en.html
 * 
 * Or write to the Free Software Foundation, Inc., 
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 **/
#ifndef DM_FX_COMPRESSOR_H
#define DM_FX_COMPRESSOR_H


/**
 * @brief      Effect: Compressor/Limiter
 * 
 *  Example:
 * 
 *     // Declare an instance of the compressor with initial values
 *     fx_compressor compy(-50.0, 			// Threshold to -50dB
 *                           100.0, 		// Ratio to 1:100 (like a limiter)
 *                           10.0, 			// Attack time in ms
 *                           100, 			// Release time in ms
 *                           3.0);			// Output gain
 *                           
 *     ...
 *     pedal.route_audio(pedal.instr_in, compy.input);
 * 		 pedal.route_audio(compy.output, pedal.amp_out);
 * 		 if (pedal.pot_0.has_changed()) {
 * 		   compy.set_threshold(pedal.pot_0.val*-40.0);
 * 		 }
 * 		  
 * 		 if (pedal.pot_1.has_changed()) {
 * 		   compy.set_ratio(pedal.pot_1.val*100.0); 
 * 		 }  
 * 		   
 * 		 if (pedal.pot_2.has_changed()) {
 * 		   compy.set_output_gain(pedal.pot_1.val*4.0);
 * 		 }  
 */	
class fx_compressor: public fx_effect {

  private:

  	// Parameters
  	float	param_threshold;
  	float	param_ratio;
  	float	param_attack;
  	float param_release;
  	float param_gain_out;

		// Control nodes
    fx_control_node node_ctrl_threshold;
    fx_control_node node_ctrl_ratio;
    fx_control_node node_ctrl_attack;
    fx_control_node node_ctrl_release;
    fx_control_node node_ctrl_out_gain;

	  void init(void) {

	    // Set class
	    type = FX_COMPRESSOR;

	    // Set name
	    strcpy(effect_name, "compressor");


	    // Assign programmable node names
	    input = &node_input;
	    output = &node_output;
	    
			// Initialize parameter stack
	    int indx = 1;
	    param_stack[indx] = &param_threshold;
	    param_stack_types[indx++] = T_FLOAT;
	    param_stack[indx] = &param_ratio;
	    param_stack_types[indx++] = T_FLOAT;
	    param_stack[indx] = &param_attack;
	    param_stack_types[indx++] = T_FLOAT;
	    param_stack[indx] = &param_release;
	    param_stack_types[indx++] = T_FLOAT;
	    param_stack[indx] = &param_gain_out;
	    param_stack_types[indx++] = T_FLOAT;    
	    total_params = indx;    

	    // Add addititonal nodes to the control stack
	    control_node_stack[total_control_nodes++] = &node_ctrl_threshold;
	    control_node_stack[total_control_nodes++] = &node_ctrl_ratio;
	    control_node_stack[total_control_nodes++] = &node_ctrl_attack;
	    control_node_stack[total_control_nodes++] = &node_ctrl_release;
	    control_node_stack[total_control_nodes++] = &node_ctrl_out_gain;

	    // Assign controls
	    threshold = &node_ctrl_threshold;
	    ratio = &node_ctrl_ratio;
	    attack = &node_ctrl_attack;
	    release = &node_ctrl_release;
	    out_gain = &node_ctrl_out_gain;

	  }

	public:

    /**
     * Audio routing node: primary audio input
     */
    fx_audio_node * input;
    
    /**
     * Audio routing node: primary audio output
     */
    fx_audio_node * output;	


    /**
     * Control routing node [input]: Compressor/limiter threshold in dB (i.e. -30.0)
     */        
    fx_control_node * threshold;


    /**
     * Control routing node [input]: Compressor/limiter compression ratio (a value of 100.0 would be a ratio of 1:100)
     */        
    fx_control_node * ratio;

    /**
     * Control routing node [input]: Compressor/limiter attack rate in milliseconds
     */        
    fx_control_node * attack;

    /**
     * Control routing node [input]: Compressor/limiter release rate in milliseconds
     */        
    fx_control_node * release;

    /**
     * Control routing node [input]: Compressor/limiter output gain (linear value so a value of 2.0 would double the signal amplitude)
     */        
    fx_control_node * out_gain;


	  
	  fx_compressor(float thresh, float ratio, float attack, float release, float gain_out):
	    node_ctrl_threshold(NODE_IN, NODE_FLOAT, "node_ctrl_threshold", this, FX_COMPRESSOR_PARAM_ID_THRESH),
	    node_ctrl_ratio(NODE_IN, NODE_FLOAT, "node_ctrl_ratio", this, FX_COMPRESSOR_PARAM_ID_RATIO),
	    node_ctrl_attack(NODE_IN, NODE_FLOAT, "node_ctrl_threshold", this, FX_COMPRESSOR_PARAM_ID_ATTACK),
	    node_ctrl_release(NODE_IN, NODE_FLOAT, "node_ctrl_release", this, FX_COMPRESSOR_PARAM_ID_RELEASE),
	    node_ctrl_out_gain(NODE_IN, NODE_FLOAT, "node_ctrl_out_gain", this, FX_COMPRESSOR_PARAM_ID_OUT_GAIN) {

	    	param_threshold = thresh;
	    	param_ratio = ratio;
	    	param_attack = attack;
	    	param_release = release;
	    	param_gain_out = gain_out;

	    	init();

    }


    /**
     * @brief      Enable the __this_effect__ (it is enabled by default)
     */
    void enable() {
      param_enabled = true; 
      parent_canvas->spi_transmit_param(FX_COMPRESSOR, instance_id, T_BOOL, FX_COMPRESSOR_PARAM_ID_ENABLED, (void *) &param_enabled);
    }

    /**
     * @brief      Bypass the __this_effect__ (will just pass clean audio through)
     */
    void bypass() {
      param_enabled = false; 
      parent_canvas->spi_transmit_param(FX_COMPRESSOR, instance_id, T_BOOL, FX_COMPRESSOR_PARAM_ID_ENABLED, (void *) &param_enabled);
    }  

    void set_threshold(float threshold) { 
      if (node_ctrl_threshold.connected) {
        return; 
      }

      param_threshold = threshold; 
      parent_canvas->spi_transmit_param(FX_COMPRESSOR, instance_id, T_FLOAT, FX_COMPRESSOR_PARAM_ID_THRESH, &param_threshold);
    }  

    void set_ratio(float ratio) { 
      if (node_ctrl_ratio.connected) {
        return; 
      }
      param_ratio = ratio; 
      parent_canvas->spi_transmit_param(FX_COMPRESSOR, instance_id, T_FLOAT, FX_COMPRESSOR_PARAM_ID_RATIO, &param_ratio);
    }  

    void set_attack(float attack) { 
      if (node_ctrl_attack.connected) {
        return; 
      }
      param_attack = attack; 
      parent_canvas->spi_transmit_param(FX_COMPRESSOR, instance_id, T_FLOAT, FX_COMPRESSOR_PARAM_ID_ATTACK, &param_attack);
    }    

    void set_release(float release) { 
      if (node_ctrl_release.connected) {
        return; 
      }
      param_release = release; 
      parent_canvas->spi_transmit_param(FX_COMPRESSOR, instance_id, T_FLOAT, FX_COMPRESSOR_PARAM_ID_RELEASE, &param_release);
    }  

    void set_output_gain(float gain_out) { 
      if (node_ctrl_out_gain.connected) {
        return; 
      }
      param_gain_out = gain_out; 
      parent_canvas->spi_transmit_param(FX_COMPRESSOR, instance_id, T_FLOAT, FX_COMPRESSOR_PARAM_ID_OUT_GAIN, &param_gain_out);
    }  

    void  print_params(void) {

  		// void print_parameter( void * val, char * name, PARAM_TYPES type)
  		Serial.println("Parameters:");
      print_parameter( &param_enabled, "Enabled", T_BOOL );
      print_parameter( &param_threshold, "Threshold (db)", T_FLOAT );
      print_parameter( &param_ratio, "Ratio", T_FLOAT );
  		print_parameter( &param_attack, "Attack time (ms)", T_FLOAT );
  		print_parameter( &param_release, "Release (ms)", T_FLOAT );
  		print_parameter( &param_gain_out, "Output gain", T_INT16 );

      Serial.println("Control Routing:");      
      print_ctrl_node_status(&node_ctrl_threshold);
      print_ctrl_node_status(&node_ctrl_ratio);
      print_ctrl_node_status(&node_ctrl_attack);
      print_ctrl_node_status(&node_ctrl_release);
      print_ctrl_node_status(&node_ctrl_out_gain);

      Serial.println("Audio Routing:");      
      print_audio_node_status(&node_input);
      print_audio_node_status(&node_output);

      Serial.println();
    }    

};

#endif 	// DM_FX_COMPRESSOR_H