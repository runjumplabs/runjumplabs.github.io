/**
 * Copyright (c) 2019 Run Jump Labs LLC.  All right reserved. 
 * 
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either  
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details. 
 * 
 * The GNU Lesser General Public License can be found here:
 * https://www.gnu.org/licenses/lgpl-3.0.en.html
 * 
 * Or write to the Free Software Foundation, Inc., 
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#ifndef DM_FX_FRAMEWORK_EFFECTS_AFX_EFFECTS_DEFINES_H_
#define DM_FX_FRAMEWORK_EFFECTS_AFX_EFFECTS_DEFINES_H_

// Enumations
typedef enum {
  FX_NONE,
  FX_AMPLITUDE_MODULATOR,
  FX_BIQUAD_FILTER,
  FX_CLIPPER,
  FX_COMPRESSOR,
  FX_DELAY,
  FX_ENVELOPE_TRACKER,
  FX_GAIN,
  FX_INSTR_SYNTH,
  FX_LOOPER,
  FX_MIXER_2,
  FX_MIXER_3,
  FX_MIXER_4,
  FX_OSCILLATOR,
  FX_PHASE_SHIFTER,
  FX_PITCH_SHIFT,
  FX_RING_MOD,
  FX_SHAPER,
  FX_SLICER,
  FX_VARIABLE_DELAY,
  CANVAS = (254),
  FX_UNDEFINED = (255),
} EFFECT_TYPE;

typedef enum {
  T_BOOL, T_INT16, T_INT32, T_FLOAT
} PARAM_TYPES;

typedef enum {
  NODE_FLOAT,
  NODE_BOOL,
  NODE_INT32,
  NODE_NOTE
} CTRL_NODE_TYPE;

typedef enum {
  OSC_NONE,
  OSC_SINE,
  OSC_TRI,
  OSC_SQUARE,
  OSC_PULSE,
  OSC_RAMP,
  OSC_TOTAL,
} OSC_TYPES;

typedef enum {
    TRANS_VERY_FAST = (1),
    TRANS_FAST = (5),
    TRANS_MED = (10),
    TRANS_SLOW = (20),
    TRANS_VERY_SLOW = (30),
  TRANS_TOTAL
} EFFECT_TRANSITION_SPEED;

// Types of biquad filters
typedef enum {
    BIQUAD_TYPE_LPF,
    BIQUAD_TYPE_HPF,
    BIQUAD_TYPE_BPF,
    BIQUAD_TYPE_NOTCH,
    BIQUAD_TYPE_PEAKING,
    BIQUAD_TYPE_L_SHELF,
    BIQUAD_TYPE_H_SHELF,
  BIQUAD_TYPE_TOTAL
} BIQUAD_FILTER_TYPE;

typedef enum {
  FILTER_WIDTH_VERY_NARROW, // Q = 8
  FILTER_WIDTH_NARROW,    // Q = 4
  FILTER_WIDTH_MEDIUM,    // Q = 1
  FILTER_WIDTH_WIDE,      // Q = 0.7071
  FILTER_WIDTH_VERY_WIDE,   // Q = 0.5
  FILTER_WIDTH_TOTAL
} BIQUAD_FILTER_WIDTH;

// Various polynomials used for clipping
typedef enum {
    POLY_SMOOTHSTEP,
    POLY_SMOOTHERSTEP,
  POLY_SIMPLE_1,
  POLY_SIMPLE_2,
  POLY_TOTAL
} POLY_CLIP_FUNC;


// Envelope tracker types
typedef enum {
  ENV_TRACK_MA,
  ENV_TRACK_TOTAL
} ENV_TRACKER_TYPE;

/*********************************************************
 * UNIVERSAL
 ********************************************************/
#define  FX_PARAM_ID_ENABLED              0
#define  FX_PARAM_OFFSET_ENABLED        0

/*********************************************************
 * AMPLITUDE MODULATOR
 ********************************************************/

// Parameters
#define  FX_AMP_MOD_PARAM_ID_ENABLED                 0
#define  FX_AMP_MOD_PARAM_ID_MOD_FREQ                1
#define  FX_AMP_MOD_PARAM_ID_MOD_PHASE               2
#define  FX_AMP_MOD_PARAM_ID_MOD_DEPTH               3
#define  FX_AMP_MOD_PARAM_ID_MOD_TYPE                4
#define  FX_AMP_MOD_PARAM_ID_EXT_MOD             5

// Offsets
#define  FX_AMP_MOD_OFFSET_ENABLED                   0
#define  FX_AMP_MOD_OFFSET_MOD_FREQ                  1
#define  FX_AMP_MOD_OFFSET_MOD_PHASE                 3
#define  FX_AMP_MOD_OFFSET_MOD_DEPTH                 5
#define  FX_AMP_MOD_OFFSET_MOD_TYPE                  7
#define  FX_AMP_MOD_OFFSET_EXT_MOD                   8

/*********************************************************
 * BIQUAD
 ********************************************************/

// Parameters
#define  FX_BIQUAD_PARAM_ID_ENABLED           0
#define  FX_BIQUAD_PARAM_ID_TYPE        1
#define  FX_BIQUAD_PARAM_ID_SPEED       2
#define  FX_BIQUAD_PARAM_ID_FREQ        3
#define  FX_BIQUAD_PARAM_ID_Q         4
#define  FX_BIQUAD_PARAM_ID_GAIN        5

// Offsets
#define  FX_BIQUAD_PARAM_OFFSET_EN        0
#define  FX_BIQUAD_PARAM_OFFSET_TYPE      1
#define  FX_BIQUAD_PARAM_OFFSET_SPEED     2
#define  FX_BIQUAD_PARAM_OFFSET_FREQ      3
#define  FX_BIQUAD_PARAM_OFFSET_Q       5
#define  FX_BIQUAD_PARAM_OFFSET_GAIN      7


/*********************************************************
 * CLIPPER
 ********************************************************/

// Parameters
#define  FX_CLIPPER_PARAM_ID_ENABLED                 0
#define  FX_CLIPPER_PARAM_ID_THRESH              1
#define  FX_CLIPPER_PARAM_ID_POLY_TYPE             2
#define  FX_CLIPPER_PARAM_ID_IN_DRIVE            3
#define  FX_CLIPPER_PARAM_ID_RECTIFY             4
#define  FX_CLIPPER_PARAM_ID_UPSAMPLE            5

// Offsets
#define  FX_CLIPPER_OFFSET_ENABLED                   0
#define  FX_CLIPPER_OFFSET_THRESH                    1
#define  FX_CLIPPER_OFFSET_POLY_TYPE                 3
#define  FX_CLIPPER_OFFSET_IN_DRIVE                  4
#define  FX_CLIPPER_OFFSET_RECTIFY                   6
#define  FX_CLIPPER_OFFSET_UPSAMPLE                  7

/*********************************************************
 * COMPRESSOR
 ********************************************************/

// Parameters
#define  FX_COMPRESSOR_PARAM_ID_ENABLED           0
#define  FX_COMPRESSOR_PARAM_ID_THRESH          1
#define  FX_COMPRESSOR_PARAM_ID_RATIO           2
#define  FX_COMPRESSOR_PARAM_ID_ATTACK            3
#define  FX_COMPRESSOR_PARAM_ID_RELEASE           4
#define  FX_COMPRESSOR_PARAM_ID_OUT_GAIN          5

// Offsets
#define  FX_COMPRESSOR_PARAM_OFFSET_EN        0
#define  FX_COMPRESSOR_PARAM_OFFSET_THRESH      1
#define  FX_COMPRESSOR_PARAM_OFFSET_RATIO     3
#define  FX_COMPRESSOR_PARAM_OFFSET_ATTACK      5
#define  FX_COMPRESSOR_PARAM_OFFSET_RELEASE     7
#define  FX_COMPRESSOR_PARAM_OFFSET_OUT_GAIN    9

/*********************************************************
 * DELAY
 ********************************************************/

// Parameters
#define  FX_DELAY_PARAM_ID_ENABLED          0
#define  FX_DELAY_PARAM_ID_LEN_MS           1
#define  FX_DELAY_PARAM_ID_LEN_MAX_MS       2
#define  FX_DELAY_PARAM_ID_FEEDBACK         3
#define  FX_DELAY_PARAM_ID_FEEDTHROUGH      4
#define  FX_DELAY_PARAM_ID_DAMPENING_EN     5
#define  FX_DELAY_PARAM_ID_DAMPENING        6
#define  FX_DELAY_PARAM_ID_EXT_FB           7

// Offsets
#define  FX_DELAY_PARAM_OFFSET_EN       0
#define  FX_DELAY_PARAM_OFFSET_DELAY_LEN    1
#define  FX_DELAY_PARAM_OFFSET_DELAY_LEN_MAX  3
#define  FX_DELAY_PARAM_OFFSET_DELAY_FB     5
#define  FX_DELAY_PARAM_OFFSET_DELAY_FT     7
#define  FX_DELAY_PARAM_OFFSET_DAMP_EN      9
#define  FX_DELAY_PARAM_OFFSET_DAMP       10
#define  FX_DELAY_PARAM_OFFSET_EXT_LOOP     12

/*********************************************************
 * ENV TRACKER
 ********************************************************/

// Parameters
#define  FX_ENV_TRACKER_PARAM_ID_ENABLED          0
#define  FX_ENV_TRACKER_PARAM_ID_ATTACK_MS      1
#define  FX_ENV_TRACKER_PARAM_ID_DECAY_MS     2
#define  FX_ENV_TRACKER_PARAM_ID_TYPE       3
#define  FX_ENV_TRACKER_PARAM_ID_TRIGGERED      4
#define  FX_ENV_TRACKER_PARAM_ID_VALUE        5

// Offsets
#define  FX_ENV_TRACKER_OFFSET_EN         0
#define  FX_ENV_TRACKER_OFFSET_ATTACK_MS      1
#define  FX_ENV_TRACKER_OFFSET_DECAY_MS       3
#define  FX_ENV_TRACKER_OFFSET_TYPE         5
#define  FX_ENV_TRACKER_OFFSET_TRIGGERED      6


/*********************************************************
 * GAIN
 ********************************************************/

// Parameters
#define  FX_GAIN_PARAM_ID_ENABLED           0
#define  FX_GAIN_PARAM_ID_GAIN            1
#define  FX_GAIN_PARAM_ID_SPEED             2

// Offsets
#define  FX_GAIN_PARAM_OFFSET_EN        0
#define  FX_GAIN_PARAM_OFFSET_GAIN        1
#define  FX_GAIN_PARAM_OFFSET_SPEED       3


/*********************************************************
 * INSTRUMENT SYNTH
 ********************************************************/

// Parameters
#define  FX_INSTR_SYNTH_PARAM_ID_ENABLED    0
#define  FX_INSTR_SYNTH_PARAM_ID_FREQ_MULT_1  1
#define  FX_INSTR_SYNTH_PARAM_ID_FREQ_MULT_2  2
#define  FX_INSTR_SYNTH_PARAM_ID_FREQ_MULT_3  3
#define  FX_INSTR_SYNTH_PARAM_ID_FREQ_MIX_1     4
#define  FX_INSTR_SYNTH_PARAM_ID_FREQ_MIX_2   5
#define  FX_INSTR_SYNTH_PARAM_ID_FREQ_MIX_3   6
#define  FX_INSTR_SYNTH_PARAM_ID_OSC_TYPE_1     7
#define  FX_INSTR_SYNTH_PARAM_ID_OSC_TYPE_2     8
#define  FX_INSTR_SYNTH_PARAM_ID_OSC_TYPE_3     9
#define  FX_INSTR_SYNTH_PARAM_ID_ATK_S      10
#define  FX_INSTR_SYNTH_PARAM_ID_RLS_S      11
#define  FX_INSTR_SYNTH_PARAM_ID_SYNTH_MIX    12
#define  FX_INSTR_SYNTH_PARAM_ID_CLEAN_MIX    13

// Offsets
#define  FX_INSTR_SYNTH_OFFSET_ENABLED      0
#define  FX_INSTR_SYNTH_OFFSET_FREQ_MULT_1    1
#define  FX_INSTR_SYNTH_OFFSET_FREQ_MULT_2    3
#define  FX_INSTR_SYNTH_OFFSET_FREQ_MULT_3    5
#define  FX_INSTR_SYNTH_OFFSET_FREQ_MIX_1     7
#define  FX_INSTR_SYNTH_OFFSET_FREQ_MIX_2   9
#define  FX_INSTR_SYNTH_OFFSET_FREQ_MIX_3   11
#define  FX_INSTR_SYNTH_OFFSET_OSC_TYPE_1     13
#define  FX_INSTR_SYNTH_OFFSET_OSC_TYPE_2     14
#define  FX_INSTR_SYNTH_OFFSET_OSC_TYPE_3     15
#define  FX_INSTR_SYNTH_OFFSET_ATK_S        16
#define  FX_INSTR_SYNTH_OFFSET_RLS_S        18
#define  FX_INSTR_SYNTH_OFFSET_SYNTH_MIX      20
#define  FX_INSTR_SYNTH_OFFSET_CLEAN_MIX      22

/*********************************************************
 * LOOPER
 ********************************************************/

// Parameters
#define  FX_LOOPER_PARAM_OFFSET_EN        0
#define  FX_LOOPER_PARAM_OFFSET_LOOP_SIZE_S   1
#define  FX_LOOPER_PARAM_OFFSET_DRY_MIX     3
#define  FX_LOOPER_PARAM_OFFSET_LOOP_MIX    5
#define  FX_LOOPER_PARAM_OFFSET_RATE      7
#define  FX_LOOPER_PARAM_OFFSET_EXT_PP      9
#define  FX_LOOPER_PARAM_OFFSET_START     10
#define  FX_LOOPER_PARAM_OFFSET_STOP      11

// Parameter and status IDs
#define  FX_LOOPER_PARAM_ID_ENABLED           0
#define  FX_LOOPER_PARAM_ID_LOOP_SIZE_S     1
#define  FX_LOOPER_PARAM_ID_DRY_MIX           2
#define  FX_LOOPER_PARAM_ID_LOOP_MIX        3
#define  FX_LOOPER_PARAM_ID_RATE          4
#define  FX_LOOPER_PARAM_ID_EXT_FB          5
#define  FX_LOOPER_PARAM_ID_START           6
#define  FX_LOOPER_PARAM_ID_STOP            7

#define  FX_LOOPER_PARAM_ID_LOOP_LEN_S      8


/*********************************************************
 * OSCILLATOR
 ********************************************************/

// Parameters
#define  FX_OSCILLATOR_PARAM_ID_ENABLED                 0
#define  FX_OSCILLATOR_PARAM_ID_FREQ                    1
#define  FX_OSCILLATOR_PARAM_ID_AMP                     2
#define  FX_OSCILLATOR_PARAM_ID_OFFSET                  3
#define  FX_OSCILLATOR_PARAM_ID_TYPE                    4
#define  FX_OSCILLATOR_PARAM_ID_OSC_PARAM1              5
#define  FX_OSCILLATOR_PARAM_ID_OSC_PARAM2              6
#define  FX_OSCILLATOR_PARAM_ID_OSC_CTRL_VAL            7


// Offsets
#define  FX_OSCILLATOR_PARAM_OFFSET_OFFSET_EN           0
#define  FX_OSCILLATOR_PARAM_OFFSET_FREQ                1
#define  FX_OSCILLATOR_PARAM_OFFSET_AMP                 3
#define  FX_OSCILLATOR_PARAM_OFFSET_OFFSET              5
#define  FX_OSCILLATOR_PARAM_OFFSET_TYPE                7
#define  FX_OSCILLATOR_PARAM_OFFSET_OSC_PARAM1          8
#define  FX_OSCILLATOR_PARAM_OFFSET_OSC_PARAM2          10


/*********************************************************
 * PHASE SHIFTER
 ********************************************************/

// Parameters
#define  FX_PHASE_SHIFTER_PARAM_ID_ENABLED      0
#define  FX_PHASE_SHIFTER_PARAM_ID_RATE_HZ    1
#define  FX_PHASE_SHIFTER_PARAM_ID_DEPTH    2
#define  FX_PHASE_SHIFTER_PARAM_ID_FEEDBACK   3
#define  FX_PHASE_SHIFTER_PARAM_ID_POLE_POS_0 4
#define  FX_PHASE_SHIFTER_PARAM_ID_POLE_POS_1 5
#define  FX_PHASE_SHIFTER_PARAM_ID_POLE_POS_2 6
#define  FX_PHASE_SHIFTER_PARAM_ID_POLE_POS_3 7
#define  FX_PHASE_SHIFTER_PARAM_ID_POLE_RNG_0 8
#define  FX_PHASE_SHIFTER_PARAM_ID_POLE_RNG_1 9
#define  FX_PHASE_SHIFTER_PARAM_ID_POLE_RNG_2 10
#define  FX_PHASE_SHIFTER_PARAM_ID_POLE_RNG_3 11


// Offsets
#define  FX_PHASE_SHIFTER_PARAM_OFFSET_EN   0
#define  FX_PHASE_SHIFTER_PARAM_OFFSET_RATE_HZ  1
#define  FX_PHASE_SHIFTER_PARAM_OFFSET_DEPTH  3
#define  FX_PHASE_SHIFTER_PARAM_OFFSET_FEEDBACK 5


/*********************************************************
 * PITCH SHIFT / PHASE VOCODER
 ********************************************************/

// Parameters
#define  FX_PITCH_SHIFT_PARAM_ID_ENABLED              0
#define  FX_PITCH_SHIFT_PARAM_ID_FREQ_SHIFT           1

// Offsets
#define  FX_PITCH_SHIFT_PARAM_OFFSET_OFFSET_EN        0
#define  FX_PITCH_SHIFT_PARAM_OFFSET_FREQ_SHIFT       1

/*********************************************************
 * RING MODULATOR
 ********************************************************/

// Parameters
#define  FX_RING_MOD_PARAM_ID_ENABLED                 0
#define  FX_RING_MOD_PARAM_ID_FREQ                    1
#define  FX_RING_MOD_PARAM_ID_DEPTH                   2

// Offsets
#define  FX_RING_MOD_PARAM_OFFSET_OFFSET_EN           0
#define  FX_RING_MOD_PARAM_OFFSET_FREQ                1
#define  FX_RING_MOD_PARAM_OFFSET_DEPTH               3


/*********************************************************
 * SHAPER
 ********************************************************/

// Parameters
#define FX_SHAPER_PARAM_ID_ENABLED        0
#define FX_SHAPER_PARAM_ID_CLEAN_MIX    1
#define FX_SHAPER_PARAM_ID_SHAPER_MIX   2
#define FX_SHAPER_PARAM_ID_OCT_1_MIX    3
#define FX_SHAPER_PARAM_ID_OCT_2_MIX    4
#define FX_SHAPER_PARAM_ID_OSC_TYPE     5

// Offsets
#define FX_SHAPER_PARAM_OFFSET_EN     0
#define FX_SHAPER_PARAM_OFFSET_CLEAN_MIX  1
#define FX_SHAPER_PARAM_OFFSET_SYNTH_MIX  3
#define FX_SHAPER_PARAM_OFFSET_OCT_1_MIX  5
#define FX_SHAPER_PARAM_OFFSET_OCT_2_MIX  7
#define FX_SHAPER_PARAM_OFFSET_OSC_TYPE   9

/*********************************************************
 * SLICER
 ********************************************************/

// Parameters
#define  FX_SLICER_PARAM_ID_ENABLED           0
#define  FX_SLICER_PARAM_ID_PERIOD            1
#define  FX_SLICER_PARAM_ID_CHANNELS          2

// Offsets
#define  FX_SLICER_PARAM_OFFSET_EN        0
#define  FX_SLICER_PARAM_OFFSET_PERIOD      1
#define  FX_SLICER_PARAM_OFFSET_CHANNELS    3

/*********************************************************
 * VARIABLE DELAY
 ********************************************************/

// Parameters
#define  FX_VAR_DELAY_PARAM_ID_ENABLED                 0
#define  FX_VAR_DELAY_PARAM_ID_MOD_FREQ                1
#define  FX_VAR_DELAY_PARAM_ID_MOD_DEPTH               2
#define  FX_VAR_DELAY_PARAM_ID_FEEDBACK                3
#define  FX_VAR_DELAY_PARAM_ID_MOD_TYPE                4
#define  FX_VAR_DELAY_PARAM_ID_EXT_MOD               5
#define  FX_VAR_DELAY_PARAM_ID_DELAY_LEN_MS            6
#define  FX_VAR_DELAY_PARAM_ID_MIX_CLEAN             7


// Offsets
#define  FX_VAR_DELAY_OFFSET_ENABLED                   0
#define  FX_VAR_DELAY_OFFSET_MOD_FREQ                  1
#define  FX_VAR_DELAY_OFFSET_MOD_DEPTH                 3
#define  FX_VAR_DELAY_OFFSET_FEEDBACK                5
#define  FX_VAR_DELAY_OFFSET_MOD_TYPE                7
#define  FX_VAR_DELAY_OFFSET_EXT_MOD               8
#define  FX_VAR_DELAY_OFFSET_DELAY_LEN_MS            9
#define  FX_VAR_DELAY_OFFSET_MIX_CLEAN               11



#endif /* DM_FX_FRAMEWORK_EFFECTS_AFX_EFFECTS_DEFINES_H_ */
