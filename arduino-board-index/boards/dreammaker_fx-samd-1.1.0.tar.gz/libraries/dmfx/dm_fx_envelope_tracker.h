/**
 * Copyright (c) 2019 Run Jump Labs LLC.  All right reserved. 
 * 
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either  
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details. 
 * 
 * The GNU Lesser General Public License can be found here:
 * https://www.gnu.org/licenses/lgpl-3.0.en.html
 * 
 * Or write to the Free Software Foundation, Inc., 
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 **/
#ifndef DM_FX_ENVELOPE_TRACKER_H
#define DM_FX_ENVELOPE_TRACKER_H

/**
 * @brief      Effect: Envelope tracker
 */
class fx_envelope_tracker:public fx_effect {

  private:

    // Parameters
    float param_decay_ms;
    float param_attack_ms;
    bool  param_triggered;
    ENV_TRACKER_TYPE param_type;

    // Control nodes
    fx_control_node node_ctrl_attack_ms;
    fx_control_node node_ctrl_decay_ms;
    fx_control_node node_ctrl_envelope;

    void init(void) {
      // Set class
      type = FX_ENVELOPE_TRACKER;

      // Set name
      strcpy(effect_name, "envelope tracker");


      // Initialize parameter stack
      int indx = 1;
      param_stack[indx] = &param_attack_ms;
      param_stack_types[indx++] = T_FLOAT;
      param_stack[indx] = &param_decay_ms;
      param_stack_types[indx++] = T_FLOAT;
      param_stack[indx] = &param_type;
      param_stack_types[indx++] = T_INT16;
      param_stack[indx] = &param_triggered;
      param_stack_types[indx++] = T_BOOL;
      total_params = indx;

      // Initialize node stacks
      control_node_stack[total_control_nodes++] = &node_ctrl_attack_ms;
      control_node_stack[total_control_nodes++] = &node_ctrl_decay_ms;
      control_node_stack[total_control_nodes++] = &node_ctrl_envelope;

      // Assign node variables to locations
      input           = &node_input;
      attack_speed_ms = &node_ctrl_attack_ms;
      decay_speed_ms  = &node_ctrl_decay_ms;
      envelope        = &node_ctrl_envelope;
    }

  public:

    // Audio node names that users will be using
    fx_audio_node * input;

    // Control node names that users will be using
    fx_control_node * decay_speed_ms;
    fx_control_node * attack_speed_ms;
    fx_control_node * envelope;

    // Constructor
    fx_envelope_tracker(float attack_speed_ms, float decay_speed_ms, bool triggered) : 
      node_ctrl_attack_ms(NODE_IN, NODE_FLOAT, "node_ctrl_attack_speed", this, FX_ENV_TRACKER_PARAM_ID_ATTACK_MS),
      node_ctrl_decay_ms(NODE_IN, NODE_FLOAT, "node_ctrl_decay_speed", this, FX_ENV_TRACKER_PARAM_ID_DECAY_MS),
      node_ctrl_envelope(NODE_OUT, NODE_FLOAT, "node_ctrl_envelope", this, FX_ENV_TRACKER_PARAM_ID_VALUE) {
    
      param_attack_ms = attack_speed_ms;
      param_decay_ms = decay_speed_ms;
      param_type = ENV_TRACK_MA;
      param_triggered = triggered;

      init();
        
    }

    void set_attack_speed_ms(float attack_speed_ms) { 
      // If this node is being controlled by a controller, don't allow a direct write to it
      if (node_ctrl_attack_ms.connected) {
        return; 
      }

      param_attack_ms = attack_speed_ms; 
      parent_canvas->spi_transmit_param(FX_ENVELOPE_TRACKER, instance_id, T_FLOAT, FX_ENV_TRACKER_PARAM_ID_ATTACK_MS, &param_attack_ms);
    }

    void set_decay_speed_ms(float decay_speed_ms) { 
      // If this node is being controlled by a controller, don't allow a direct write to it
      if (node_ctrl_decay_ms.connected) {
        return; 
      }

      param_decay_ms = decay_speed_ms; 
      parent_canvas->spi_transmit_param(FX_ENVELOPE_TRACKER, instance_id, T_FLOAT, FX_ENV_TRACKER_PARAM_ID_DECAY_MS, &param_decay_ms);
    }

    void  print_params(void) {

      // void print_parameter( void * val, char * name, PARAM_TYPES type)
      Serial.println("Parameters:");
      print_parameter( &param_attack_ms, "Attack speed (ms) ", T_FLOAT );
      print_parameter( &param_decay_ms, "Decay speed (ms) ", T_FLOAT );
      print_parameter( &param_triggered, "Triggered ", T_BOOL );

      Serial.println("Control Routing:");     
      print_ctrl_node_status(&node_ctrl_attack_ms);
      print_ctrl_node_status(&node_ctrl_decay_ms);
      print_ctrl_node_status(&node_ctrl_envelope);

      Serial.println("Audio Routing:");      
      print_audio_node_status(&node_input);

      Serial.println();
    }    


};

#endif // DM_FX_ENVELOPE_TRACKER_H