/**
 * Copyright (c) 2019 Run Jump Labs LLC.  All right reserved. 
 * 
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either  
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details. 
 * 
 * The GNU Lesser General Public License can be found here:
 * https://www.gnu.org/licenses/lgpl-3.0.en.html
 * 
 * Or write to the Free Software Foundation, Inc., 
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#ifndef DM_FX_INSTR_SYNTH_H
#define DM_FX_INSTR_SYNTH_H

/**
 * @brief      Effect: Instrument synth - your basic guitar/bass synth 
 */
class fx_instr_synth: public fx_effect {
  
  private:
		
		// Parameters
    float param_freq_mult[3];
    float param_freq_mix[3];
    uint16_t param_type[3];
    float	param_attack_s;
    float param_release_s;
    float param_synth_mix;
    float param_clean_mix;

    void init() {

			// Set class
	    type = FX_INSTR_SYNTH;

	    // Set name
	    strcpy(effect_name, "instrument synth");      

			// Assign programmable node names
	    input = &node_input;
	    output = &node_output;

		  	// Initialize parameter stack
	    int indx = 1;
	    param_stack[indx] = &param_freq_mult[0];
	    param_stack_types[indx++] = T_FLOAT;
	    param_stack[indx] = &param_freq_mult[1];
	    param_stack_types[indx++] = T_FLOAT;
	    param_stack[indx] = &param_freq_mult[2];
	    param_stack_types[indx++] = T_FLOAT;

	    param_stack[indx] = &param_freq_mix[0];
	    param_stack_types[indx++] = T_FLOAT;
	    param_stack[indx] = &param_freq_mix[1];
	    param_stack_types[indx++] = T_FLOAT;
	    param_stack[indx] = &param_freq_mix[2];
	    param_stack_types[indx++] = T_FLOAT;

	    param_stack[indx] = &param_type[0];
	    param_stack_types[indx++] = T_INT16;
	    param_stack[indx] = &param_type[1];
	    param_stack_types[indx++] = T_INT16;
	    param_stack[indx] = &param_type[2];
	    param_stack_types[indx++] = T_INT16;

	    param_stack[indx] = &param_attack_s;
	    param_stack_types[indx++] = T_FLOAT;
	    param_stack[indx] = &param_release_s;
	    param_stack_types[indx++] = T_FLOAT;

	    param_stack[indx] = &param_synth_mix;
	    param_stack_types[indx++] = T_FLOAT;
	    param_stack[indx] = &param_clean_mix;
	    param_stack_types[indx++] = T_FLOAT;

	    total_params = indx;         
    };

  public:
 		/**
		 * Audio routing node: primary audio input
		 */
	  fx_audio_node * input;
	  /**
	   * Audio routing node: primary audio output
	   */
	  fx_audio_node * output;

	  fx_instr_synth(float freq_mult_1,
	  								 float freq_mult_2, 
	  								 float freq_mult_3,
	  								 float synth_1_mix,
	  								 float synth_2_mix,
	  								 float synth_3_mix,
	  								 OSC_TYPES synth_1_type,
	  								 OSC_TYPES synth_2_type,
	  								 OSC_TYPES synth_3_type,
	  								 float attack_seconds,
	  								 float release_seconds,
	  								 float synth_mix,
	  								 float clean_mix) {
		
				// Set parameters
			  param_freq_mult[0] = freq_mult_1;
			  param_freq_mult[1] = freq_mult_2;
			  param_freq_mult[2] = freq_mult_3;
			  param_freq_mix[0] = synth_1_mix;
			  param_freq_mix[1] = synth_2_mix;
			  param_freq_mix[2] = synth_3_mix;
			  param_type[0] = (uint16_t) synth_1_type;
			  param_type[1] = (uint16_t) synth_2_type;
			  param_type[2] = (uint16_t) synth_3_type;
			  param_attack_s = attack_seconds;
			  param_release_s = release_seconds;
			  param_synth_mix = synth_mix;
			  param_clean_mix = clean_mix;

		    init();
 		}

		/**
		 * @brief      Enable the __this_effect__ (it is enabled by default)
		 */
	  void enable() {
	    param_enabled = true; 
	    parent_canvas->spi_transmit_param(FX_INSTR_SYNTH, instance_id, T_BOOL, FX_INSTR_SYNTH_PARAM_ID_ENABLED, (void *) &param_enabled);
	  }

	  /**
	   * @brief      Bypass the __this_effect__ (will just pass clean audio through)
	   */
	  void bypass() {
	    param_enabled = false; 
	    parent_canvas->spi_transmit_param(FX_INSTR_SYNTH, instance_id, T_BOOL, FX_INSTR_SYNTH_PARAM_ID_ENABLED, (void *) &param_enabled);
	  }   		 

};


#endif // DM_FX_INSTR_SYNTH_H