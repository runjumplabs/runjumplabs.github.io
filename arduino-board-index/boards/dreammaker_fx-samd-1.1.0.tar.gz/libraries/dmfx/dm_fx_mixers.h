/**
 * Copyright (c) 2019 Run Jump Labs LLC.  All right reserved. 
 * 
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either  
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details. 
 * 
 * The GNU Lesser General Public License can be found here:
 * https://www.gnu.org/licenses/lgpl-3.0.en.html
 * 
 * Or write to the Free Software Foundation, Inc., 
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#ifndef DM_FX_MIXERS_H
#define DM_FX_MIXERS_H

/**
 * @brief      Utility: 2 channel mixer 
 */
class fx_mixer_2: public fx_effect {

	public:

    // Additional audio nodes
    fx_audio_node node_input_2;

	// Audio node names that users will be using
    fx_audio_node * input_1;
    fx_audio_node * input_2;
    fx_audio_node * output;

		fx_mixer_2(void) : node_input_2(NODE_IN, "input_2", this) {
      // Set class
      type = FX_MIXER_2;

      // Set name
      strcpy(effect_name, "mixer_2");      

      input_1 = &node_input;
      input_2 = &node_input_2;
      output = &node_output;

      // Add additional nodes to the audio stack
      audio_node_stack[total_audio_nodes++] = &node_input_2;
		}
		void  print_params(void) {
     	Serial.println("Audio Routing:");      
      print_audio_node_status(&node_input);
      print_audio_node_status(&node_input_2);
      print_audio_node_status(&node_output);
		}		
};

/**
 * @brief      Utility: 3 channel mixer 
 */
class fx_mixer_3: public fx_effect {

	public:

    // Additional audio nodes
    fx_audio_node node_input_2;
    fx_audio_node node_input_3;
    fx_audio_node node_dummy_output;
    

		// Audio node names that users will be using
    fx_audio_node * input_1;
    fx_audio_node * input_2;
    fx_audio_node * input_3;
    fx_audio_node * output;

		fx_mixer_3(void) : node_input_2(NODE_IN, "input_2", this), node_input_3(NODE_IN, "input_3", this), node_dummy_output(NODE_OUT, "dummy", this)  {
      // Set class
      type = FX_MIXER_3;

      // Set name
      strcpy(effect_name, "mixer_3");      

      input_1 = &node_input;
      input_2 = &node_input_2;
      input_3 = &node_input_3;
      output = &node_output;

      // Add additional nodes to the audio stack
      audio_node_stack[total_audio_nodes++] = &node_input_2;
      audio_node_stack[total_audio_nodes++] = &node_dummy_output;		// dummy output node since inputs and outputs go in pairs
      audio_node_stack[total_audio_nodes++] = &node_input_3;
		}

		void  print_params(void) {
     	Serial.println("Audio Routing:");      
      print_audio_node_status(&node_input);
      print_audio_node_status(&node_input_2);
      print_audio_node_status(&node_input_3);
      print_audio_node_status(&node_output);
		}
};

/**
 * @brief      Utility: 4 channel mixer 
 */
class fx_mixer_4: public fx_effect {

	public:

    // Additional audio nodes
    fx_audio_node node_input_2;
    fx_audio_node node_input_3;
    fx_audio_node node_input_4;
    fx_audio_node node_dummy_output;

		// Audio node names that users will be using
    fx_audio_node * input_1;
    fx_audio_node * input_2;
    fx_audio_node * input_3;
    fx_audio_node * input_4;
    fx_audio_node * output;

		fx_mixer_4(void) : node_input_2(NODE_IN, "input_2", this), node_input_3(NODE_IN, "input_3", this), node_input_4(NODE_IN, "input_3", this), node_dummy_output(NODE_OUT, "dummy", this){
      // Set class
      type = FX_MIXER_4;

      // Set name
      strcpy(effect_name, "mixer_4");      

      input_1 = &node_input;
      input_2 = &node_input_2;
      input_3 = &node_input_3;
      input_4 = &node_input_4;
      output = &node_output;

      // Add additional nodes to the audio stack
      audio_node_stack[total_audio_nodes++] = &node_input_2;
      audio_node_stack[total_audio_nodes++] = &node_dummy_output;		// dummy output node since inputs and outputs go in pairs      
      audio_node_stack[total_audio_nodes++] = &node_input_3;
      audio_node_stack[total_audio_nodes++] = &node_dummy_output;		// dummy output node since inputs and outputs go in pairs      
      audio_node_stack[total_audio_nodes++] = &node_input_4;
	}
		void  print_params(void) {
     	Serial.println("Audio Routing:");      
      print_audio_node_status(&node_input);
      print_audio_node_status(&node_input_2);
      print_audio_node_status(&node_input_3);
      print_audio_node_status(&node_input_4);
      print_audio_node_status(&node_output);
		}	
};


#endif 	// DM_FX_MIXERS_H