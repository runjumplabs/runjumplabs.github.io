/**
 * Copyright (c) 2019 Run Jump Labs LLC.  All right reserved. 
 * 
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either  
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details. 
 * 
 * The GNU Lesser General Public License can be found here:
 * https://www.gnu.org/licenses/lgpl-3.0.en.html
 * 
 * Or write to the Free Software Foundation, Inc., 
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#ifndef DM_FX_OSCILLATOR_H
#define DM_FX_OSCILLATOR_H

/**
 * @brief      Utility: Oscillator that can has both audio and control outputs
 */
class fx_oscillator: public fx_effect {

  private:
    OSC_TYPES	param_type;
    float 		param_freq;
    float 		param_amp;
    float 		param_offset;
    float 		param_osc_param1;
    float 		param_osc_param2;

    // Control nodes
    fx_control_node node_ctrl_freq;
    fx_control_node node_ctrl_amp;
    fx_control_node node_ctrl_offset;
    fx_control_node node_ctrl_value;

    void init(void) {
       // Set class
      type = FX_OSCILLATOR;

      // Set name
      strcpy(effect_name, "oscillator");

      // Assign programmable node names
      output = &node_output;      

      // Initialize parameter stack
      int indx = 1;
      param_stack[indx] = &param_freq;
      param_stack_types[indx++] = T_FLOAT;

      param_stack[indx] = &param_amp;
      param_stack_types[indx++] = T_FLOAT;

      param_stack[indx] = &param_offset;
      param_stack_types[indx++] = T_FLOAT;

      param_stack[indx] = &param_type;
      param_stack_types[indx++] = T_INT16;

      param_stack[indx] = &param_osc_param1;
      param_stack_types[indx++] = T_FLOAT;

      param_stack[indx] = &param_osc_param2;
      param_stack_types[indx++] = T_FLOAT;

      total_params = indx;      


      // Add addiitonal notes to the control stack
      control_node_stack[total_control_nodes++] = &node_ctrl_freq;
      control_node_stack[total_control_nodes++] = &node_ctrl_amp;
      control_node_stack[total_control_nodes++] = &node_ctrl_offset;
      control_node_stack[total_control_nodes++] = &node_ctrl_value;

      freq = &node_ctrl_freq;
      amplitude = &node_ctrl_amp;
      offset = &node_ctrl_offset;
      value = &node_ctrl_value;      
    }


 public:

  // Audio node names that users will be using
  fx_audio_node * output;

	// Control node names that users will be using
	fx_control_node * freq;
	fx_control_node * amplitude;
	fx_control_node * offset;
	fx_control_node * value;

  /**
   * @brief      Basic constructor for an oscillator when used as an audio source
   *
   * @param[in]  osc_type   The osc type (see OSC_TYPES)
   * @param[in]  freq       The frequency in Hz
   * @param[in]  amplitude  The amplitude (linear scale e.g. 0.0 -> 1.0 typically)
   */
  fx_oscillator(OSC_TYPES osc_type, float freq, float amplitude ) : 
    node_ctrl_freq(NODE_IN, NODE_FLOAT, "node_ctrl_freq", this, FX_OSCILLATOR_PARAM_ID_FREQ),
    node_ctrl_amp(NODE_IN, NODE_FLOAT, "node_ctrl_amp", this, FX_OSCILLATOR_PARAM_ID_AMP),
    node_ctrl_offset(NODE_IN, NODE_FLOAT, "node_ctrl_offset", this, FX_OSCILLATOR_PARAM_ID_OFFSET),
    node_ctrl_value(NODE_OUT, NODE_FLOAT, "node_ctrl_value", this, FX_OSCILLATOR_PARAM_ID_OSC_CTRL_VAL)  {

      // Set parameters
      param_type = osc_type;
      param_freq = freq;
      param_amp = amplitude;
      param_offset = 0.0;

      param_osc_param1 = 0.0;
      param_osc_param2 = 0.0;

      init();

    }


  /**
   * @brief      Basic constructor for an oscillator used as a control source
   *
   * @param[in]  osc_type   The osc type (see OSC_TYPES)
   * @param[in]  freq       The frequency in Hz
   * @param[in]  amplitude  The amplitude (linear scale e.g. 0.0 -> 1.0 typically)
   * @param[in]  offset     The DC offset (for example, if you wanted an LFO that ranged from 400 - 800, you could
   *                        set the offset to 600 and the amplitude of the waveform for 200.)
   */
  fx_oscillator(OSC_TYPES	osc_type, float freq, float amplitude, float offset ) : 
    node_ctrl_freq(NODE_IN, NODE_FLOAT, "node_ctrl_freq", this, FX_OSCILLATOR_PARAM_ID_FREQ),
    node_ctrl_amp(NODE_IN, NODE_FLOAT, "node_ctrl_amp", this, FX_OSCILLATOR_PARAM_ID_AMP),
    node_ctrl_offset(NODE_IN, NODE_FLOAT, "node_ctrl_offset", this, FX_OSCILLATOR_PARAM_ID_OFFSET),
    node_ctrl_value(NODE_OUT, NODE_FLOAT, "node_ctrl_value", this, FX_OSCILLATOR_PARAM_ID_OSC_CTRL_VAL)  {

      // Set parameters
      param_type = osc_type;
      param_freq = freq;
      param_amp = amplitude;
      param_offset = offset;

      param_osc_param1 = 0.0;
      param_osc_param2 = 0.0;

      init();

    }

    /**
     * @brief      Enable the oscillator (it is enabled by default)
     */
    void enable() {
      param_enabled = true; 
      parent_canvas->spi_transmit_param(FX_OSCILLATOR, instance_id, T_BOOL, FX_OSCILLATOR_PARAM_ID_ENABLED, (void *) &param_enabled);
    }

    /**
     * @brief      Bypass the oscillator (it will provide just a constant value)
     */
    void bypass() {
      param_enabled = false; 
      parent_canvas->spi_transmit_param(FX_OSCILLATOR, instance_id, T_BOOL, FX_OSCILLATOR_PARAM_ID_ENABLED, (void *) &param_enabled);
    }      
    

    /**
     * @brief      Upates the frequency in Hz of the current oscillator
     *
     * @param[in]  freq  The frequency in Hz
     */
    void set_frequency(float freq) { 

      // If this node is being controlled by a controller, don't allow a direct write to it
      if (node_ctrl_freq.connected) {
        return; 
      }

      param_freq = freq; 
      parent_canvas->spi_transmit_param(FX_OSCILLATOR, instance_id, T_FLOAT, FX_OSCILLATOR_PARAM_ID_FREQ, &node_ctrl_freq);
    }   


    /**
     * @brief      Updates the amplitude for the current oscillator
     *
     * @param[in]  amplitude  The amplitude (linear)
     */
    void set_amplitude(float amplitude) { 

      // If this node is being controlled by a controller, don't allow a direct write to it
      if (node_ctrl_amp.connected) {
        return; 
      }

      param_amp = amplitude; 
      parent_canvas->spi_transmit_param(FX_OSCILLATOR, instance_id, T_FLOAT, FX_OSCILLATOR_PARAM_ID_AMP, &node_ctrl_amp);
    }   

    /**
     * @brief      Sets the offset of the oscillator when it's being used as a controller 
     *
     * @param[in]  offset  The offset value
     */
    void set_offset(float offset) {
      // If this node is being controlled by a controller, don't allow a direct write to it
      if (node_ctrl_offset.connected) {
        return; 
      }

      param_offset = offset; 
      parent_canvas->spi_transmit_param(FX_OSCILLATOR, instance_id, T_FLOAT, FX_OSCILLATOR_PARAM_ID_OFFSET, &node_ctrl_offset);

    }


    /**
     * @brief      Print the parameters for this effect
     */
    void  print_params(void) {

      // void print_parameter( void * val, char * name, PARAM_TYPES type)
      Serial.println("Parameters:");
      print_parameter( &param_enabled, "Enabled", T_BOOL );
      print_parameter( &param_type, "Oscillator type", T_FLOAT );
      print_parameter( &param_freq, "Frequency (Hz)", T_FLOAT );
      print_parameter( &param_amp, "Amplitude", T_FLOAT );
      print_parameter( &param_offset, "Offset", T_FLOAT );

      Serial.println("Control Routing:");      
      print_ctrl_node_status(&node_ctrl_freq);
      print_ctrl_node_status(&node_ctrl_amp);
      print_ctrl_node_status(&node_ctrl_offset);
      print_ctrl_node_status(&node_ctrl_value);

      Serial.println("Audio Routing:");      
      print_audio_node_status(&node_input);
      print_audio_node_status(&node_output);

      Serial.println();
    }    

};


#endif 	// DM_FX_OSCILLATOR_H