/**
 * Copyright (c) 2019 Run Jump Labs LLC.  All right reserved. 
 * 
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either  
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details. 
 * 
 * The GNU Lesser General Public License can be found here:
 * https://www.gnu.org/licenses/lgpl-3.0.en.html
 * 
 * Or write to the Free Software Foundation, Inc., 
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#ifndef DM_FX_SHAPER_H
#define DM_FX_SHAPER_H

/**
 * @brief      Effect: Slicer - chops up audio in the time domain and pipes to different effects
 */
class fx_shaper: public fx_effect {

  private:

    // Parameters
    float param_clean_mix;
    float param_shaper_mix;
    float param_oct_1_mix;
    float param_oct_2_mix;
    OSC_TYPES param_osc_type;

    // Additional audio nodes
    fx_audio_node node_dummy_input;    
    fx_audio_node node_synth_output;
    fx_audio_node node_oct_1_output;
    fx_audio_node node_oct_2_output;

    // Control nodes
    fx_control_node node_ctrl_clean_mix;
    fx_control_node node_ctrl_shaper_mix;
    fx_control_node node_ctrl_oct_1_mix;
    fx_control_node node_ctrl_oct_2_mix;

    void init() {
	    // Set class
	    type = FX_SHAPER;

	    // Set name
	    strcpy(effect_name, "shaper");      

		  // Assign programmable node names
	    input = &node_input;
	    output = &node_output;	    
      synth_output = &node_synth_output;
      oct_1_output = &node_oct_1_output;
      oct_2_output = &node_oct_2_output;

      // Add additional nodes to the audio stack
      audio_node_stack[total_audio_nodes++] = &node_dummy_input;   // dummy output node since inputs and outputs go in pairs
      audio_node_stack[total_audio_nodes++] = &node_synth_output; 
      audio_node_stack[total_audio_nodes++] = &node_dummy_input;   // dummy output node since inputs and outputs go in pairs
      audio_node_stack[total_audio_nodes++] = &node_oct_1_output; 
      audio_node_stack[total_audio_nodes++] = &node_dummy_input;   // dummy output node since inputs and outputs go in pairs
      audio_node_stack[total_audio_nodes++] = &node_oct_2_output; 

      // Initialize parameter stack
      int indx = 1;
      param_stack[indx] = &param_clean_mix;
      param_stack_types[indx++] = T_FLOAT;

      param_stack[indx] = &param_shaper_mix;
      param_stack_types[indx++] = T_FLOAT;

      param_stack[indx] = &param_oct_1_mix;
      param_stack_types[indx++] = T_FLOAT;

      param_stack[indx] = &param_oct_2_mix;
      param_stack_types[indx++] = T_FLOAT;

      param_stack[indx] = &param_osc_type;
      param_stack_types[indx++] = T_INT16;

      total_params = indx;        


      // Assign controls
      clean_mix = &node_ctrl_clean_mix;
      shaper_mix = &node_ctrl_shaper_mix;
      oct_1_mix = &node_ctrl_oct_1_mix;
      oct_2_mix = &node_ctrl_oct_2_mix;

    }



  public:

    /**
     * Audio routing node: primary audio input
     */
    fx_audio_node * input;
    /**
     * Audio routing node: primary audio output
     */
    fx_audio_node * output;

    /**
     * Audio routing node: synth only raw output 
     */
    fx_audio_node * synth_output;

    /**
     * Audio routing node: octave 1 raw output
     */
    fx_audio_node * oct_1_output;

    /**
     * Audio routing node: octave 2 raw output
     */
    fx_audio_node * oct_2_output;


    /**
     * Control routing node: Clean mix (0.0 -> 1.0)
     */
    fx_control_node * clean_mix;    

    /**
     * Control routing node: Shaper mix (0.0 -> 1.0)
     */
    fx_control_node * shaper_mix;    

    /**
     * Control routing node: Octave below mix (0.0 -> 1.0)
     */
    fx_control_node * oct_1_mix;    

    /**
     * Control routing node: Two octaves below mix (0.0 -> 1.0)
     */
    fx_control_node * oct_2_mix;

    /**
     * @brief      Constructor for the shaper
     *
     * @param[in]  clean_mix   The clean mix (0.0 -> 1.0)
     * @param[in]  shaper_mix  The shaper mix (0.0 -> 1.0)
     * @param[in]  oct_1_mix   The octal 1 mix (0.0 -> 1.0)
     * @param[in]  oct_2_mix   The octal 2 mix (0.0 -> 1.0)
     */
    fx_shaper(float clean_mix, float shaper_mix, float oct_1_mix, float oct_2_mix) :
      node_dummy_input(NODE_IN, "dummy", this),
      node_synth_output(NODE_OUT, "synth raw output", this), 
      node_oct_1_output(NODE_OUT, "octave 1 raw output", this), 
      node_oct_2_output(NODE_OUT, "octave 2 raw output", this), 
      node_ctrl_clean_mix(NODE_IN, NODE_FLOAT, "clean mix", this, FX_SHAPER_PARAM_ID_CLEAN_MIX),
      node_ctrl_shaper_mix(NODE_IN, NODE_FLOAT, "shaper mix", this, FX_SHAPER_PARAM_ID_SHAPER_MIX),
      node_ctrl_oct_1_mix(NODE_IN, NODE_FLOAT, "octave 1 down mix", this, FX_SHAPER_PARAM_ID_OCT_1_MIX),
      node_ctrl_oct_2_mix(NODE_IN, NODE_FLOAT, "octave 2 down mix", this, FX_SHAPER_PARAM_ID_OCT_2_MIX) {

      param_clean_mix = clean_mix;
      param_shaper_mix = shaper_mix;
      param_oct_1_mix = oct_1_mix;
      param_oct_2_mix = oct_2_mix;

      init();

    }

    /**
     * @brief      Enable the amplitude modululator (it is enabled by default)
     */
    void enable() {
      param_enabled = true; 
      parent_canvas->spi_transmit_param(FX_SHAPER, instance_id, T_BOOL, FX_SHAPER_PARAM_ID_ENABLED, (void *) &param_enabled);
    }

    /**
     * @brief      Bypass the amplitude modululator  (will just pass clean audio through)
     */
    void bypass() {
      param_enabled = false; 
      parent_canvas->spi_transmit_param(FX_SHAPER, instance_id, T_BOOL, FX_SHAPER_PARAM_ID_ENABLED, (void *) &param_enabled);
    }  

    void set_clean_mix(float clean_mix) { 
      if (node_ctrl_clean_mix.connected) {
        return; 
      }

      param_clean_mix = clean_mix; 
      parent_canvas->spi_transmit_param(FX_SHAPER, instance_id, T_FLOAT, FX_SHAPER_PARAM_ID_CLEAN_MIX, &param_clean_mix);
    }

    void set_shaper_mix(float shaper_mix) { 
      if (node_ctrl_shaper_mix.connected) {
        return; 
      }

      param_shaper_mix = shaper_mix; 
      parent_canvas->spi_transmit_param(FX_SHAPER, instance_id, T_FLOAT, FX_SHAPER_PARAM_ID_SHAPER_MIX, &param_shaper_mix);
    }

    void set_oct_1_mix(float oct_1_mix) { 
      if (node_ctrl_oct_1_mix.connected) {
        return; 
      }

      param_oct_1_mix = oct_1_mix; 
      parent_canvas->spi_transmit_param(FX_SHAPER, instance_id, T_FLOAT, FX_SHAPER_PARAM_ID_OCT_1_MIX, &param_oct_1_mix);
    }  

    void set_oct_2_mix(float oct_2_mix) { 
      if (node_ctrl_oct_2_mix.connected) {
        return; 
      }

      param_oct_2_mix = oct_2_mix; 
      parent_canvas->spi_transmit_param(FX_SHAPER, instance_id, T_FLOAT, FX_SHAPER_PARAM_ID_OCT_2_MIX, &param_oct_2_mix);
    }  

    /**
     * @brief      Print the parameters for this effect
     */
    void  print_params(void) {

      // void print_parameter( void * val, char * name, PARAM_TYPES type)
      Serial.println("Parameters:");
      print_parameter( &param_enabled, "Enabled", T_BOOL );
      print_parameter( &param_clean_mix, "Clean mix", T_FLOAT );
      print_parameter( &param_shaper_mix, "Shaper mix", T_FLOAT );
      print_parameter( &param_oct_1_mix, "Octave below mix", T_FLOAT );
      print_parameter( &param_oct_2_mix, "Two octaves below mix", T_FLOAT );

      Serial.println("Control Routing:");      
      print_ctrl_node_status(&node_ctrl_clean_mix);
      print_ctrl_node_status(&node_ctrl_shaper_mix);
      print_ctrl_node_status(&node_ctrl_oct_1_mix);
      print_ctrl_node_status(&node_ctrl_oct_2_mix);

      Serial.println("Audio Routing:");      
      print_audio_node_status(&node_input);
      print_audio_node_status(&node_output);
      print_audio_node_status(&node_synth_output);
      print_audio_node_status(&node_oct_1_output);
      print_audio_node_status(&node_oct_2_output);


      Serial.println();
    }
};

#endif // DM_FX_SHAPER_H